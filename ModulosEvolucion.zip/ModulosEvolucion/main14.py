import pygame
import random

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Fuente para mostrar texto
font = pygame.font.Font(None, 36)

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje
player_size = 50
player_x = WIDTH // 2 - player_size // 2
player_y = HEIGHT // 2 - player_size // 2
player_speed = 0.5
player_color = (0, 255, 0)  # Verde por defecto
player_health = 100  # Barra de salud del personaje
health_bar_width = 200  # Ancho de la barra de salud

# Dirección inicial del disparo
last_direction = "UP"

# Configuración de los tipos de proyectiles y enemigos
projectile_types = {
    1: ((255, 0, 0), "Rojo"),
    2: ((0, 255, 0), "Verde"),
    3: ((0, 0, 255), "Azul"),
    4: ((255, 255, 0), "Amarillo"),
    5: ((255, 0, 255), "Magenta"),
    6: ((0, 255, 255), "Cian"),
    7: ((255, 165, 0), "Naranja"),
    8: ((128, 0, 128), "Púrpura"),
    9: ((255, 255, 255), "Blanco")
}
current_projectile_color = projectile_types[1][0]  # Rojo por defecto

# Configuración del rayo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 5

# Configuración de las rondas
current_round = 1
round_active = True
round_color = projectile_types[current_round][0]
num_enemies = 5
wave = 1  # 1 = estáticos, 2 = perseguidores
enemy_speed = 0.2  # Velocidad del enemigo
chase_range = 150  # Rango en el que los enemigos empiezan a perseguir al jugador

# Contador de puntos
score = 0
enemies = []


def generate_enemies():
    global enemies, round_color, wave
    enemies = []
    for _ in range(num_enemies):
        enemy_x = random.randint(0, WIDTH - player_size)
        enemy_y = random.randint(0, HEIGHT - player_size)
        enemies.append([enemy_x, enemy_y, round_color, "wandering", random.choice([-1, 1]), random.choice([-1, 1])])

generate_enemies()


# Bucle principal
def main():
    global player_x, player_y, last_direction, current_projectile_color, current_round
    global round_active, round_color, player_color, score, wave, player_health

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    last_direction = "LEFT"
                if event.key == pygame.K_RIGHT:
                    last_direction = "RIGHT"
                if event.key == pygame.K_UP:
                    last_direction = "UP"
                if event.key == pygame.K_DOWN:
                    last_direction = "DOWN"
                
                # Cambiar el color del proyectil con los números del 1 al 9
                if pygame.K_1 <= event.key <= pygame.K_9:
                    num = event.key - pygame.K_0
                    if num in projectile_types:
                        current_projectile_color = projectile_types[num][0]
                
                # Cambiar el color del personaje con el número 0
                if event.key == pygame.K_0:
                    player_color = random.choice(list(projectile_types.values()))[0]
                
                # Disparar un rayo en la última dirección con el color actual
                if event.key == pygame.K_SPACE:
                    ray_x = player_x + player_size // 2 - ray_width // 2
                    ray_y = player_y + player_size // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction, current_projectile_color])

        
        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= player_speed
        if keys[pygame.K_RIGHT]:
            player_x += player_speed
        if keys[pygame.K_UP]:
            player_y -= player_speed
        if keys[pygame.K_DOWN]:
            player_y += player_speed

        # Mover los rayos según la dirección
        for ray in rays[:]:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed
        
        # Eliminar rayos que salgan de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]

        
        # Mover los enemigos
        for enemy in enemies:
            dx = player_x - enemy[0]
            dy = player_y - enemy[1]
            distance = (dx ** 2 + dy ** 2) ** 0.5
            
            if distance < chase_range:
                enemy[3] = "chasing"  # Cambia a modo persecución
                enemy[0] += (dx / distance) * enemy_speed
                enemy[1] += (dy / distance) * enemy_speed
            else:
                enemy[3] = "wandering"  # Se mantiene en modo deambular
                enemy[0] += enemy[4] * enemy_speed
                enemy[1] += enemy[5] * enemy_speed
                if random.random() < 0.02:
                    enemy[4] = random.choice([-1, 1])
                    enemy[5] = random.choice([-1, 1])
        # Detectar colisión del personaje con los enemigos y reducir salud
        for enemy in enemies:
            if pygame.Rect(enemy[0], enemy[1], player_size, player_size).colliderect(
                    pygame.Rect(player_x, player_y, player_size, player_size)):
                player_health -= 10  # Reducir salud al contacto con el enemigo
                player_health = max(0, player_health)  # Evitar valores negativos           
        
        # Detectar colisiones entre rayos y enemigos
        for ray in rays[:]:
            for enemy in enemies[:]:
                if pygame.Rect(enemy[0], enemy[1], player_size, player_size).colliderect(
                        pygame.Rect(ray[0], ray[1], ray_width, ray_height)):
                    if enemy[2] == ray[3]:  # Solo eliminar si los colores coinciden
                        if player_color == enemy[2]:
                            score += 100
                        else:
                            score += 50
                        enemies.remove(enemy)
                        rays.remove(ray)
                        player_health += 5  # Recuperar salud al eliminar enemigo
                        player_health = min(100, player_health)  # Límite de salud a 100
                        break           
        
        # Avanzar de ronda cuando no queden enemigos
        if not enemies:
            if wave == 1:
                wave = 2
                generate_enemies()
            elif current_round < 9:
                current_round += 1
                wave = 1
                round_color = projectile_types[current_round][0]
                generate_enemies()
                


        # Dibujar elementos en pantalla
        screen.fill(BG_COLOR)

        # Dibujar la barra de salud correctamente
        pygame.draw.rect(screen, (255, 0, 0), (20, 50, health_bar_width, 10))  # Barra roja
        pygame.draw.rect(screen, (0, 255, 0), (20, 50, (player_health / 100) * health_bar_width, 10))  # Barra verde

        pygame.draw.rect(screen, player_color, (player_x, player_y, player_size, player_size))
        for ray in rays:
            pygame.draw.rect(screen, ray[3], (ray[0], ray[1], ray_width, ray_height))
        for enemy in enemies:
            pygame.draw.rect(screen, round_color, (enemy[0], enemy[1], player_size, player_size))
        
        # Mostrar texto en pantalla
        round_text = font.render(f"Ronda {current_round} - Oleada {wave}", True, (255, 255, 255))
        score_text = font.render(f"Puntos: {score}", True, (255, 255, 255))
        screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 20))
        screen.blit(score_text, (20, 20))
        
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()



















