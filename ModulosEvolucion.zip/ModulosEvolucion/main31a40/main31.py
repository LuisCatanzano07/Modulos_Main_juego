import pygame
import random
import time
import json
import os

# 🟢 Inicialización de Pygame
pygame.init()

### 1️⃣ CONFIGURACIÓN GENERAL ###
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")
font = pygame.font.Font(None, 36)
SAVE_FILE = "savegame.json"
BG_COLOR = (30, 30, 30)

### 2️⃣ DATOS DEL JUGADOR Y ENEMIGOS ###
player = {
    "x": WIDTH // 2 - 25,
    "y": HEIGHT // 2 - 25,
    "size": 50,
    "color": (0, 255, 0),
    "health": 100,
    "max_health": 100,
    "energy": 100,
    "max_energy": 100,
    "strength": 10,
    "resistance": 5,
    "speed": 0.5,
    "exp": 0,
    "exp_to_next_level": 100,
    "level": 1
}

enemy_base_stats = {
    "size": 50,
    "max_health": 100,
    "max_energy": 100,
    "strength": 8,
    "resistance": 3,
    "speed": 0.3
}

### 3️⃣ INVENTARIO E ÍTEMS ###
inventory = {"stored_health": 0, "stored_freeze": 0, "stored_slow": 0}
ITEM_TYPES = {
    "health": ((0, 255, 0), "Salud"),
    "freeze": ((0, 0, 255), "Congelación"),
    "slow": ((255, 255, 0), "Ralentización"),
    "stored_health": ((144, 238, 144), "Poción de Salud"),
    "stored_freeze": ((135, 206, 250), "Poción de Congelación"),
    "stored_slow": ((240, 230, 140), "Poción de Ralentización")
}

### 4️⃣ RONDAS, RAYOS Y LABERINTO ###
current_round = 1
wave = 1
score = 0
rays = []
ray_speed = 5
maze_walls = []
walls_destroyed = 0

# Modo invencible
invincible_mode = False


### 5️⃣ MISIONES Y ESTADOS ###
current_mission = None
missions_completed = 0
freeze_timer = 0
slow_active = False
start_time = 0

# Configuración del personaje con atributos mejorables
player = {
    "x": WIDTH // 2 - 25,           # Posición X inicial (centrado)
    "y": HEIGHT // 2 - 25,          # Posición Y inicial (centrado)
    "size": 50,                     # Tamaño del jugador (cuadrado de 50x50)
    "color": (0, 255, 0),           # Color (verde por defecto)
    
    # Estadísticas principales
    "health": 100,                  # Salud actual
    "max_health": 100,              # Salud máxima
    "energy": 100,                  # Energía actual (para habilidades y disparos)
    "max_energy": 100,              # Energía máxima
    "strength": 10,                 # Fuerza (afecta daño)
    "resistance": 5,                # Resistencia (reduce daño recibido)
    "speed": 0.5,                   # Velocidad de movimiento
    
    # Progresión y niveles
    "exp": 0,                       # Experiencia actual
    "exp_to_next_level": 100,       # Experiencia necesaria para subir de nivel
    "level": 1                      # Nivel actual
}

# Configuración de proyectiles por tipo y color
projectile_types = {
    1: ((255, 0, 0), "Rojo"),         # Rojo
    2: ((0, 255, 0), "Verde"),        # Verde
    3: ((0, 0, 255), "Azul"),         # Azul
    4: ((255, 255, 0), "Amarillo"),   # Amarillo
    5: ((255, 0, 255), "Magenta"),    # Magenta
    6: ((0, 255, 255), "Cian"),       # Cian
    7: ((255, 165, 0), "Naranja"),    # Naranja
    8: ((128, 0, 128), "Púrpura"),    # Púrpura
    9: ((255, 255, 255), "Blanco")    # Blanco
}

# Configuración del rayo
ray_width = 5    # Ancho del rayo
ray_height = 20  # Altura del rayo
rays = []        # Lista para almacenar los rayos activos
ray_speed = 5    # Velocidad del rayo


# Función para ubicar al jugador en una posición válida
def place_player():
    """Ubica al jugador en una posición aleatoria válida fuera de las paredes."""
    while True:
        player["x"] = random.randint(5, WIDTH - player["size"] - 5)
        player["y"] = random.randint(5, HEIGHT - player["size"] - 5)
        
        # Verifica si la posición es válida (fuera de paredes)
        if is_position_valid(player["x"], player["y"], player["size"]):
            break

# Función para verificar si una posición está libre de paredes
def is_position_valid(x, y, size):
    """Verifica si la posición del jugador colisiona con una pared del laberinto."""
    test_rect = pygame.Rect(x, y, size, size)
    for wall in maze_walls:
        wall_rect = pygame.Rect(wall["x"], wall["y"], wall["width"], wall["height"])
        if test_rect.colliderect(wall_rect):
            return False
    return True




def save_game():
    """Guarda el estado actual del juego en un archivo JSON."""
    save_data = {
        "player": player,
        "current_round": current_round,
        "wave": wave,
        "score": score,
        "enemies": enemies,
        "items": items,
        "inventory": inventory,
        "maze_walls": maze_walls,
        "start_time": time.time() - start_time
    }
    with open(SAVE_FILE, "w") as f:
        json.dump(save_data, f)
    print("💾 Juego guardado correctamente.")

def load_game():
    """Carga la partida guardada desde un archivo JSON."""
    global player, current_round, wave, score, enemies, items, maze_walls, inventory, start_time
    
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as f:
            save_data = json.load(f)
            player = save_data["player"]
            current_round = save_data["current_round"]
            wave = save_data["wave"]
            score = save_data["score"]
            enemies = save_data["enemies"]
            items = save_data["items"]
            maze_walls = save_data["maze_walls"]
            inventory = save_data.get("inventory", {"stored_health": 0, "stored_freeze": 0, "stored_slow": 0})
            start_time = time.time() - save_data["start_time"]
        print("✅ Partida cargada correctamente.")
    else:
        print("⚠️ No se encontró una partida guardada.")


def level_up():
    """Sube de nivel al jugador y mejora sus atributos."""
    player["level"] += 1
    player["exp"] = 0
    player["exp_to_next_level"] += 50

    player["max_health"] += 10
    player["max_energy"] += 10
    player["strength"] += 2
    player["resistance"] += 1
    player["speed"] += 0.05

    player["health"] = player["max_health"]
    player["energy"] = player["max_energy"]

    print(f"🎉 ¡Nivel {player['level']} alcanzado! Atributos mejorados.")

def use_inventory_item(item_type):
    """Usa un ítem del inventario si está disponible."""
    global freeze_timer, slow_active
    if inventory.get(item_type, 0) > 0:
        inventory[item_type] -= 1
        if item_type == 'stored_health':
            player['health'] = min(player['max_health'], player['health'] + 30)
            print(f"🩹 Usaste una poción de salud. Salud actual: {player['health']}")
        elif item_type == 'stored_freeze':
            freeze_timer = time.time() + 5
            print("❄️ Usaste una poción de congelación. Enemigos congelados.")
        elif item_type == 'stored_slow':
            slow_active = True
            print("🐌 Usaste una poción de ralentización. Enemigos más lentos.")
    else:
        print(f"⚠️ No tienes {ITEM_TYPES.get(item_type, ['Desconocido'])[1]} disponibles.")

def apply_item_effect(item_type):
    """Aplica efectos al jugador cuando recoge o usa un ítem."""
    global freeze_timer, slow_active

    if item_type == "health":
        old_health = player["health"]
        player["health"] = min(player["max_health"], player["health"] + 30)
        print(f"🩹 Recogiste un ítem de salud (+30). Salud: {old_health} → {player['health']}")

    elif item_type == "freeze":
        freeze_timer = time.time() + 5  # Enemigos quedan congelados por 5 segundos
        print("❄️ Recogiste un ítem de congelación. ¡Enemigos congelados durante 5 segundos!")

    elif item_type == "slow":
        slow_active = True
        print("🐌 Recogiste un ítem de ralentización. ¡Enemigos más lentos durante 10 segundos!")

    elif item_type == "stored_health":
        old_health = player["health"]
        player["health"] = min(player["max_health"], player["health"] + 30)
        print(f"🧪 Usaste una poción de salud. Salud: {old_health} → {player['health']}")

    elif item_type == "stored_freeze":
        freeze_timer = time.time() + 5
        print("❄️ Usaste una poción de congelación. ¡Enemigos congelados durante 5 segundos!")

    elif item_type == "stored_slow":
        slow_active = True
        print("🐌 Usaste una poción de ralentización. ¡Enemigos más lentos durante 10 segundos!")

    else:
        print(f"⚠️ Efecto no reconocido para el ítem: {item_type}")

def generate_items():
    """Genera ítems en posiciones aleatorias con la clave correcta."""
    global items
    items = []
    for _ in range(6):  
        item_type = random.choice(list(ITEM_TYPES.keys()))
        item = {
            "x": random.randint(50, WIDTH - 50),
            "y": random.randint(50, HEIGHT - 50),
            "type": item_type
        }
        items.append(item)


def render_inventory():
    """Muestra el inventario en la esquina superior derecha."""
    inventory_title = font.render("Inventario:", True, (255, 255, 255))
    screen.blit(inventory_title, (WIDTH - 220, 80))
    y_offset = 120

    for item, count in inventory.items():
        item_name = ITEM_TYPES[item][1]  # Obtiene el nombre desde ITEM_TYPES
        item_color = ITEM_TYPES[item][0]  # Obtiene el color desde ITEM_TYPES

        item_text = font.render(f"{item_name}: {count}", True, item_color)
        screen.blit(item_text, (WIDTH - 220, y_offset))
        y_offset += 30

    # Instrucciones rápidas
    instructions = [
        ("[Q] Usar Poción de Salud", ITEM_TYPES["stored_health"][0]),
        ("[W] Usar Poción de Congelación", ITEM_TYPES["stored_freeze"][0]),
        ("[E] Usar Poción de Ralentización", ITEM_TYPES["stored_slow"][0]),
    ]

    for instr, color in instructions:
        instr_text = font.render(instr, True, color)
        screen.blit(instr_text, (WIDTH - 280, y_offset))
        y_offset += 30

def generate_enemies():
    """Genera enemigos con comportamientos y estadísticas escalables según la ronda."""
    global enemies
    enemies = []

    round_color = projectile_types[current_round][0]  # Color asociado a la ronda

    # Cantidad de enemigos aumenta según la ronda
    num_enemies = 5 + current_round * 2

    for _ in range(num_enemies):
        while True:
            enemy_x = random.randint(5, WIDTH - player["size"] - 5)
            enemy_y = random.randint(5, HEIGHT - player["size"] - 5)
            if is_position_valid(enemy_x, enemy_y, player["size"]):
                break

        enemy_type = random.choice(["hunter", "patroller", "erratic", "tank", "shooter"])

        base_health = enemy_base_stats["max_health"] + (current_round * 10)
        base_speed = enemy_base_stats["speed"] + (current_round * 0.05)
        base_strength = enemy_base_stats["strength"] + (current_round * 2)
        base_resistance = enemy_base_stats["resistance"] + (current_round * 1)

        enemy = {
            "x": enemy_x,
            "y": enemy_y,
            "size": player["size"],
            "color": round_color,
            "health": base_health,
            "max_health": base_health,
            "energy": 100,
            "max_energy": enemy_base_stats["max_energy"],
            "strength": base_strength,
            "resistance": base_resistance,
            "speed": base_speed,
            "type": enemy_type,
            "direction": random.choice(["LEFT", "RIGHT", "UP", "DOWN"]),
            "change_direction_timer": time.time() + random.uniform(1, 3),
            "shoot_timer": time.time() + random.uniform(2, 5) if enemy_type == "shooter" else None
        }

        enemies.append(enemy)

    print(f"🧟 Generados {len(enemies)} enemigos para la Ronda {current_round}")

def apply_damage(attacker, defender):
    """Calcula y aplica el daño basado en la fuerza del atacante y la resistencia del defensor."""
    
    # 🛡️ Verificar si el jugador está en modo invencible antes de calcular el daño
    if invincible_mode and defender == player:
        print("🛡️ Jugador invencible, no recibe daño.")
        return  # Sale sin aplicar daño
    
    # 💥 Calcular daño basado en la fuerza y resistencia
    damage = max(1, attacker["strength"] - defender["resistance"])
    defender["health"] -= damage

    print(f"💥 {attacker['color']} atacó a {defender['color']} causando {damage} de daño.")

    # 🩸 Verificar si el defensor fue derrotado
    if defender["health"] <= 0:
        defender["health"] = 0
        print(f"☠️ {defender['color']} ha sido derrotado.")

        # 👾 Recompensas si el defensor es enemigo
        if defender in enemies:
            enemies.remove(defender)
            update_mission_progress("kill_enemies")  # Actualizar progreso de misión

            # 🔋 Recuperación de salud y energía
            player["health"] = min(player["max_health"], player["health"] + 5)
            player["energy"] = min(player["max_energy"], player["energy"] + 10)

            # ⭐ Experiencia obtenida
            gained_exp = 50 + (defender["strength"] * 2) + (defender["resistance"] * 2)
            player["exp"] += gained_exp
            print(f"✨ +{gained_exp} EXP ganada por eliminar al enemigo")

            # 🚀 Verificar si el jugador sube de nivel
            if player["exp"] >= player["exp_to_next_level"]:
                level_up()

        # 💀 Fin del juego si el defensor es el jugador
        elif defender == player:
            print("💀 El jugador ha sido derrotado. Fin del juego.")
            game_over()


def handle_collisions():
    """Gestiona todas las colisiones en el juego."""
    global score, player

    # 📌 1. Colisión entre jugador y enemigos
    for enemy in enemies:
        player_rect = pygame.Rect(player["x"], player["y"], player["size"], player["size"])
        enemy_rect = pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"])

        if player_rect.colliderect(enemy_rect):
            apply_damage(enemy, player)  # El enemigo ataca al jugador
            apply_damage(player, enemy)  # El jugador también contraataca

    # 📌 2. Colisión entre rayos y enemigos
    for ray in rays[:]:
        ray_rect = pygame.Rect(ray[0], ray[1], ray_width, ray_height)
        for enemy in enemies[:]:
            enemy_rect = pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"])
            if ray_rect.colliderect(enemy_rect):
                if enemy["color"] == ray[3]:  # Solo si el color coincide
                    apply_damage(player, enemy)
                    rays.remove(ray)
                    break  # Evita múltiples colisiones con el mismo rayo

    # 📌 Colisión del jugador con ítems
    for item in items[:]:
        item_rect = pygame.Rect(item["x"], item["y"], 20, 20)
        player_rect = pygame.Rect(player["x"], player["y"], player["size"], player["size"])

        if player_rect.colliderect(item_rect):
            if item["type"].startswith("stored_"):
                inventory[item["type"]] += 1
                print(f"📦 Recogiste {ITEM_TYPES[item['type']][1]} (+1)")
            else:
                apply_item_effect(item["type"])
            items.remove(item)


    # 📌 4. Colisión entre rayos y paredes
    for ray in rays[:]:
        ray_rect = pygame.Rect(ray[0], ray[1], ray_width, ray_height)
        for wall in maze_walls[:]:
            wall_rect = pygame.Rect(wall["x"], wall["y"], wall["width"], wall["height"])
            if ray_rect.colliderect(wall_rect):
                if ray[3] == wall["color"]:  # Solo destruye si coincide el color
                    maze_walls.remove(wall)
                    rays.remove(ray)
                    score += 50
                    player["exp"] += 30
                    print(f"💥 Destruiste una pared ({score} puntos, +30 EXP)")
                    update_mission_progress("destroy_walls")
                    break

    # 📌 5. Revisión de experiencia para subir de nivel
    if player["exp"] >= player["exp_to_next_level"]:
        level_up()

def generate_maze():
    """Genera un laberinto con paredes de distintos colores que pueden destruirse con rayos del mismo color."""
    global maze_walls
    maze_walls = []
    wall_size = 50
    num_walls = 15  # Número de paredes aleatorias

    for _ in range(num_walls):
        wall_x = random.randint(1, (WIDTH // wall_size) - 2) * wall_size
        wall_y = random.randint(1, (HEIGHT // wall_size) - 2) * wall_size
        wall_color = random.choice(list(projectile_types.values()))[0]  # Color aleatorio de proyectiles
        maze_walls.append({
            "x": wall_x,
            "y": wall_y,
            "width": wall_size,
            "height": wall_size,
            "color": wall_color
        })

    print(f"🏗️ Generado laberinto con {len(maze_walls)} paredes de colores.")

def check_collision_with_maze(x, y):
    """Verifica si la posición (x, y) colisiona con alguna pared del laberinto."""
    player_rect = pygame.Rect(x, y, player["size"], player["size"])  # Área del jugador
    
    for wall in maze_walls:
        wall_rect = pygame.Rect(wall["x"], wall["y"], wall["width"], wall["height"])
        if player_rect.colliderect(wall_rect):
            return True  # Colisión detectada

    return False  # No hay colisión

def generate_mission():
    """Genera una nueva misión aleatoria con un objetivo y descripción."""
    global current_mission

    # Definición de tipos de misiones con sus objetivos y descripciones
    mission_types = [
        {"type": "kill_enemies", "goal": random.randint(3, 7), "description": "Elimina {} enemigos."},
        {"type": "survive_time", "goal": random.randint(15, 40), "description": "Sobrevive {} segundos sin ser golpeado."},
        {"type": "collect_items", "goal": random.randint(2, 5), "description": "Recoge {} ítems."},
        {"type": "shoot_projectiles", "goal": random.randint(5, 15), "description": "Dispara {} rayos."},
        {"type": "destroy_walls", "goal": random.randint(3, 7), "description": "Destruye {} paredes de color."}
    ]

    # Selecciona una misión aleatoria
    current_mission = random.choice(mission_types)
    
    # Inicializa el progreso y formatea la descripción
    current_mission["progress"] = 0
    current_mission["description"] = current_mission["description"].format(current_mission["goal"])
    
    print(f"🎯 Nueva misión: {current_mission['description']}")

def update_mission_progress(event_type, amount=1):
    """Actualiza el progreso de la misión según el tipo de evento."""
    global current_mission

    if not current_mission:
        return  # No hay misión activa, salir de la función

    # Verifica si el evento coincide con la misión actual
    if current_mission["type"] == event_type:
        current_mission["progress"] += amount
        print(f"📈 Progreso de misión: {current_mission['progress']}/{current_mission['goal']}")

        # Comprueba si se ha alcanzado el objetivo
        if current_mission["progress"] >= current_mission["goal"]:
            complete_mission()  # Llama a la función para completar la misión

def complete_mission():
    """Otorga recompensas al completar una misión y genera una nueva."""
    global current_mission, missions_completed
    missions_completed += 1  # Incrementa el contador de misiones completadas
    print(f"🎯 ¡Misión completada!: {current_mission['description']}")

    # 🎁 Selección aleatoria de recompensa
    rewards = [
        {"type": "exp", "value": random.randint(50, 150), "description": "+{} EXP"},
        {"type": "stored_health", "value": 1, "description": "+1 Poción de Salud"},
        {"type": "stored_freeze", "value": 1, "description": "+1 Poción de Congelación"},
        {"type": "stored_slow", "value": 1, "description": "+1 Poción de Ralentización"},
        {"type": "score", "value": random.randint(100, 300), "description": "+{} Puntos"}
    ]

    reward = random.choice(rewards)  # Selecciona una recompensa al azar

    # 💰 Aplicar la recompensa según su tipo
    if reward["type"] == "exp":
        player["exp"] += reward["value"]
        print(f"✨ Recompensa: {reward['description'].format(reward['value'])}")
    elif reward["type"].startswith("stored_"):
        inventory[reward["type"]] += reward["value"]
        print(f"📦 Recompensa: {reward['description'].format(reward['value'])}")
    elif reward["type"] == "score":
        global score
        score += reward["value"]
        print(f"💎 Recompensa: {reward['description'].format(reward['value'])}")

    # 🏅 Bonus adicional por cada 5 misiones completadas
    if missions_completed % 5 == 0:
        player["max_health"] += 10
        player["strength"] += 1
        print("🌟 Bonus especial: +10 Salud Máxima, +1 Fuerza")

    # 🧹 Finalizar misión actual y generar una nueva
    current_mission = None
    generate_mission()

def display_mission():
    """Muestra la misión actual en la pantalla."""
    if current_mission:
        mission_text = font.render(
            f"Misión: {current_mission['description']} ({current_mission['progress']}/{current_mission['goal']})", 
            True, (255, 255, 255)
        )
        screen.blit(mission_text, (20, 140))

        # Muestra una barra de progreso para la misión
        progress_width = 300
        progress_height = 10
        progress_x = 20
        progress_y = 170

        pygame.draw.rect(screen, (100, 100, 100), (progress_x, progress_y, progress_width, progress_height))  # Fondo
        current_width = (current_mission['progress'] / current_mission['goal']) * progress_width
        pygame.draw.rect(screen, (0, 255, 0), (progress_x, progress_y, current_width, progress_height))  # Progreso

def pause_menu():
    """Menú de pausa para mejorar atributos del jugador y enemigos usando experiencia."""
    paused = True
    
    while paused:
        screen.fill((50, 50, 50))  # Fondo gris oscuro

        # Texto principal del menú
        title_text = font.render("Menú de Pausa - Mejora de Atributos", True, (255, 255, 255))
        exp_text = font.render(f"EXP Disponible: {player['exp']}", True, (255, 255, 255))
        resume_text = font.render("Presiona R para continuar", True, (255, 255, 255))

        # Opciones de mejora
        options = [
            "1 - Aumentar Salud (+20) [Coste: 50 EXP]",
            "2 - Aumentar Energía (+20) [Coste: 50 EXP]",
            "3 - Aumentar Fuerza (+2) [Coste: 75 EXP]",
            "4 - Aumentar Resistencia (+2) [Coste: 75 EXP]",
            "5 - Aumentar Velocidad (+0.1) [Coste: 100 EXP]",
            "6 - Aumentar Vida de Enemigos (+20) [Coste: 100 EXP]",
            "7 - Aumentar Fuerza de Enemigos (+2) [Coste: 125 EXP]",
            "8 - Aumentar Velocidad de Enemigos (+0.1) [Coste: 150 EXP]"
        ]

        # Mostrar textos en pantalla
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 50))
        screen.blit(exp_text, (WIDTH // 2 - exp_text.get_width() // 2, 100))
        screen.blit(resume_text, (WIDTH // 2 - resume_text.get_width() // 2, 500))

        for i, option in enumerate(options):
            option_text = font.render(option, True, (255, 255, 255))
            screen.blit(option_text, (WIDTH // 4, 150 + i * 40))

        pygame.display.flip()

        # Manejo de eventos del menú de pausa
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    paused = False  # Salir del menú de pausa

                # Mejoras del jugador
                elif event.key == pygame.K_1 and player["exp"] >= 50:
                    player["max_health"] += 20
                    player["exp"] -= 50
                    print("🩹 Salud máxima aumentada (+20)")

                elif event.key == pygame.K_2 and player["exp"] >= 50:
                    player["max_energy"] += 20
                    player["exp"] -= 50
                    print("⚡ Energía máxima aumentada (+20)")

                elif event.key == pygame.K_3 and player["exp"] >= 75:
                    player["strength"] += 2
                    player["exp"] -= 75
                    print("💪 Fuerza aumentada (+2)")

                elif event.key == pygame.K_4 and player["exp"] >= 75:
                    player["resistance"] += 2
                    player["exp"] -= 75
                    print("🛡️ Resistencia aumentada (+2)")

                elif event.key == pygame.K_5 and player["exp"] >= 100:
                    player["speed"] += 0.1
                    player["exp"] -= 100
                    print("🏃 Velocidad aumentada (+0.1)")

                # Mejoras de enemigos
                elif event.key == pygame.K_6 and player["exp"] >= 100:
                    enemy_base_stats["max_health"] += 20
                    player["exp"] -= 100
                    print("🧟 Vida máxima de enemigos aumentada (+20)")

                elif event.key == pygame.K_7 and player["exp"] >= 125:
                    enemy_base_stats["strength"] += 2
                    player["exp"] -= 125
                    print("⚔️ Fuerza de enemigos aumentada (+2)")

                elif event.key == pygame.K_8 and player["exp"] >= 150:
                    enemy_base_stats["speed"] += 0.1
                    player["exp"] -= 150
                    print("💨 Velocidad de enemigos aumentada (+0.1)")

def advance_round():
    """Avanza a la siguiente ronda y ajusta la dificultad."""
    global current_round, wave

    if wave == 1:
        # Primera oleada: Generar enemigos e ítems
        wave = 2
        generate_enemies()
        generate_items()
    elif current_round < 9:
        # Siguiente ronda
        current_round += 1
        wave = 1

        # Incrementos en dificultad
        enemy_base_stats["max_health"] += 10
        enemy_base_stats["strength"] += 2
        enemy_base_stats["resistance"] += 1
        enemy_base_stats["speed"] += 0.05  # Incremento de velocidad de enemigos

        print(f"🔥 ¡Ronda {current_round}! Los enemigos son más fuertes.")

        # Regenerar entorno
        generate_maze()
        generate_enemies()
        generate_items()
    else:
        # Fin del juego tras 9 rondas
        print("🎉 Has completado todas las rondas. ¡Victoria!")
        game_over()

def restart_game():
    """Reinicia el juego restaurando todas las variables y comenzando desde el principio."""
    global player, current_round, wave, score, enemies, items, rays, start_time, inventory, current_mission

    # 📌 Restaurar atributos del jugador
    player.update({
        "x": WIDTH // 2 - 25,
        "y": HEIGHT // 2 - 25,
        "health": 100,
        "max_health": 100,
        "energy": 100,
        "max_energy": 100,
        "strength": 10,
        "resistance": 5,
        "speed": 0.5,
        "exp": 0,
        "exp_to_next_level": 100,
        "level": 1
    })

    # 📌 Reiniciar progreso de juego
    current_round = 1
    wave = 1
    score = 0
    rays = []
    enemies = []
    items = []
    inventory = {"stored_health": 0, "stored_freeze": 0, "stored_slow": 0}
    current_mission = None  # Reiniciar misión activa

    # 📌 Reiniciar tiempo
    start_time = time.time()

    print("🔄 Juego reiniciado. ¡Buena suerte!")

    # 📌 Regenerar el entorno
    generate_maze()
    place_player()
    generate_enemies()
    generate_items()

    # 📌 Reiniciar el bucle principal
    main()

def regenerate_stats():
    """Regenera la salud y energía del jugador y enemigos progresivamente."""
    # 🧵 Regeneración de energía del jugador
    if player["energy"] < player["max_energy"]:
        player["energy"] += 0.1 + (player["level"] * 0.05)  # Aumenta con el nivel
        player["energy"] = min(player["energy"], player["max_energy"])  # Límite máximo

    # ❤️ Regeneración de salud del jugador (depende de la resistencia)
    if player["health"] < player["max_health"] and player["resistance"] > 5:
        player["health"] += 0.05 * player["resistance"]  # Cuanto más resistente, más rápido se regenera
        player["health"] = min(player["health"], player["max_health"])  # Límite máximo

    # 👾 Regeneración de enemigos (salud y energía)
    for enemy in enemies:
        # Energía del enemigo (depende de la resistencia)
        if enemy["energy"] < enemy["max_energy"]:
            enemy["energy"] += 0.05 + (enemy["resistance"] * 0.02)
            enemy["energy"] = min(enemy["energy"], enemy["max_energy"])  # Límite máximo

        # Salud del enemigo (depende de la resistencia)
        if enemy["health"] < enemy["max_health"] and enemy["resistance"] > 5:
            enemy["health"] += 0.02 * enemy["resistance"]  # Más resistencia, más regeneración
            enemy["health"] = min(enemy["health"], enemy["max_health"])  # Límite máximo

def draw_status_bar(x, y, width, current_value, max_value, bg_color, fg_color):
    """Dibuja una barra de estado (salud o energía) en la pantalla.

    Args:
        x (int): Posición X de la barra.
        y (int): Posición Y de la barra.
        width (int): Ancho total de la barra.
        current_value (float): Valor actual (ej. salud actual).
        max_value (float): Valor máximo (ej. salud máxima).
        bg_color (tuple): Color de fondo de la barra.
        fg_color (tuple): Color de la barra principal.
    """
    # Fondo de la barra
    pygame.draw.rect(screen, bg_color, (x, y, width, 5))
    
    # Ancho proporcional al valor actual
    bar_width = (current_value / max_value) * width
    
    # Barra de estado principal
    pygame.draw.rect(screen, fg_color, (x, y, bar_width, 5))

def display_player_info():
    """Muestra la información del jugador en pantalla, incluyendo nivel, experiencia, y puntos."""
    
    # Texto del nivel
    level_text = font.render(f"Nivel: {player['level']}", True, (255, 255, 255))
    screen.blit(level_text, (20, 80))

    # Texto de experiencia
    exp_text = font.render(f"EXP: {player['exp']}/{player['exp_to_next_level']}", True, (255, 255, 255))
    screen.blit(exp_text, (20, 110))

    # Texto de puntos
    score_text = font.render(f"Puntos: {score}", True, (255, 255, 255))
    screen.blit(score_text, (20, 20))

    # Texto de la ronda actual y oleada
    round_text = font.render(f"Ronda {current_round} - Oleada {wave}", True, (255, 255, 255))
    screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 20))

    # Texto de misiones completadas
    missions_text = font.render(f"Misiones Completadas: {missions_completed}", True, (255, 255, 255))
    screen.blit(missions_text, (20, 140))

    # Mostrar si está activado el modo invencible
    invincible_text = font.render("INVENCIBLE" if invincible_mode else "", True, (255, 215, 0))
    screen.blit(invincible_text, (20, 140))

def render_game():
    """Renderiza todos los elementos del juego en pantalla."""
    # Limpiar la pantalla antes de renderizar
    screen.fill(BG_COLOR)

    # 📌 Dibujar el laberinto
    for wall in maze_walls:
        pygame.draw.rect(
            screen, 
            wall["color"], 
            (wall["x"], wall["y"], wall["width"], wall["height"])
        )

    # 📌 Dibujar el reloj en pantalla
    elapsed_time = int(time.time() - start_time)
    timer_text = font.render(f"Tiempo: {elapsed_time}s", True, (255, 255, 255))
    screen.blit(timer_text, (WIDTH - 150, 20))

    # 📌 Dibujar ítems en pantalla
    for item in items:
        pygame.draw.rect(
            screen,
            ITEM_TYPES[item["type"]][0],  # Accede al color usando la clave "type"
            (item["x"], item["y"], 20, 20)
        )


    # 📌 Dibujar personaje (jugador)
    pygame.draw.rect(
        screen, 
        player["color"], 
        (player["x"], player["y"], player["size"], player["size"])
    )

    # 📌 Dibujar barra de salud del jugador
    draw_status_bar(
        player["x"], player["y"] - 10, player["size"],
        player["health"], player["max_health"],
        (255, 0, 0), (0, 255, 0)
    )

    # 📌 Dibujar barra de energía del jugador
    draw_status_bar(
        player["x"], player["y"] - 5, player["size"],
        player["energy"], player["max_energy"],
        (50, 50, 255), (0, 100, 255)
    )

    # 📌 Dibujar enemigos
    for enemy in enemies:
        pygame.draw.rect(
            screen, 
            enemy["color"], 
            (enemy["x"], enemy["y"], enemy["size"], enemy["size"])
        )
        draw_status_bar(
            enemy["x"], enemy["y"] - 10, enemy["size"],
            enemy["health"], enemy["max_health"],
            (255, 0, 0), (0, 255, 0)
        )

    # 📌 Dibujar rayos
    for ray in rays:
        pygame.draw.rect(
            screen, 
            ray[3], 
            (ray[0], ray[1], ray_width, ray_height)
        )

    # 📌 Mostrar información del jugador
    display_player_info()

    # 📌 Mostrar la misión actual
    display_mission()

    # 📌 Mostrar inventario
    render_inventory()

    # 📌 Actualizar la pantalla después de renderizar
    pygame.display.flip()

def main_menu():
    """Muestra el menú de inicio con la opción de elegir la ronda y cargar partida."""
    global current_round, load_available
    menu_running = True
    selected_round = 1  # Ronda inicial por defecto
    load_available = os.path.exists(SAVE_FILE)  # Verifica si hay una partida guardada

    while menu_running:
        # Limpiar pantalla
        screen.fill((0, 0, 0))

        # Títulos y opciones del menú
        title_text = font.render("Mi Juego en Pygame", True, (255, 255, 255))
        start_text = font.render("Presiona ENTER para iniciar", True, (255, 255, 255))
        round_text = font.render(f"Seleccionar Ronda: {selected_round}", True, (255, 255, 255))
        exit_text = font.render("Presiona ESC para salir", True, (255, 255, 255))
        load_text = font.render(
            "Presiona L para cargar partida" if load_available else "No hay partidas guardadas",
            True, (255, 255, 255)
        )

        # Posicionar los textos en la pantalla
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2))
        screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, HEIGHT // 2 + 50))
        screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 100))
        screen.blit(load_text, (WIDTH // 2 - load_text.get_width() // 2, HEIGHT // 2 + 150))

        # Actualizar pantalla
        pygame.display.flip()

        # Manejo de eventos del menú
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Iniciar nueva partida
                    current_round = selected_round
                    load_available = False
                    menu_running = False

                if event.key == pygame.K_ESCAPE:  # Salir del juego
                    pygame.quit()
                    exit()

                if event.key == pygame.K_UP:  # Subir ronda
                    selected_round = min(9, selected_round + 1)

                if event.key == pygame.K_DOWN:  # Bajar ronda
                    selected_round = max(1, selected_round - 1)

                if event.key == pygame.K_l and load_available:  # Cargar partida
                    load_game()
                    menu_running = False

def game_over():
    """Muestra la pantalla de fin del juego con puntaje y tiempo."""
    global running

    # Fondo negro
    screen.fill((0, 0, 0))

    # Mensajes de finalización
    game_over_text = font.render("¡Juego Finalizado!", True, (255, 255, 255))
    score_text = font.render(f"Puntos obtenidos: {score}", True, (255, 255, 255))
    time_text = font.render(f"Tiempo de juego: {int(time.time() - start_time)}s", True, (255, 255, 255))
    restart_text = font.render("Presiona R para reiniciar o ESC para salir", True, (255, 255, 255))

    # Posicionar textos en pantalla
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 3))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
    screen.blit(time_text, (WIDTH // 2 - time_text.get_width() // 2, HEIGHT // 2 + 50))
    screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 100))

    # Actualizar pantalla
    pygame.display.flip()

    # Esperar entrada del usuario para salir o reiniciar
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting = False  # Salir del bucle para reiniciar el juego
                    restart_game()
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()

def main():
    """Bucle principal del juego."""
    global current_round, wave, freeze_timer, slow_active, start_time, score, last_direction
    global current_projectile_color, running

    # Iniciar cronómetro
    start_time = time.time()

    # Si no es una partida cargada, generar todo desde cero
    if not load_available:
        generate_maze()
        place_player()
        generate_enemies()
        generate_items()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_game()  # Guardar la partida antes de salir
                running = False

            # Menú de pausa
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                pause_menu()

            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
                    last_direction = {
                        pygame.K_LEFT: "LEFT",
                        pygame.K_RIGHT: "RIGHT",
                        pygame.K_UP: "UP",
                        pygame.K_DOWN: "DOWN"
                    }[event.key]

                # Cambiar el color del proyectil (1 al 9)
                if pygame.K_1 <= event.key <= pygame.K_9:
                    num = event.key - pygame.K_0
                    if num in projectile_types:
                        current_projectile_color = projectile_types[num][0]

                # Cambiar el color del personaje (tecla 0)
                if event.key == pygame.K_0:
                    player["color"] = random.choice(list(projectile_types.values()))[0]

                # Disparar un rayo
                if event.key == pygame.K_SPACE and player["energy"] >= 10:
                    ray_x = player["x"] + player["size"] // 2 - ray_width // 2
                    ray_y = player["y"] + player["size"] // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction, current_projectile_color])
                    player["energy"] -= 10
                    update_mission_progress("shoot_projectiles")

                # Activar/Desactivar modo invencible (por ejemplo, con la tecla I)
                if event.key == pygame.K_i:
                    global invincible_mode
                    invincible_mode = not invincible_mode
                    status = "activado" if invincible_mode else "desactivado"
                    print(f"🛡️ Modo invencible {status}")



        # 📌 Movimiento del jugador con colisiones y borde de pantalla
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player["x"] - player["speed"] >= 0 and not check_collision_with_maze(player["x"] - player["speed"], player["y"]):
            player["x"] -= player["speed"]
        if keys[pygame.K_RIGHT] and player["x"] + player["speed"] + player["size"] <= WIDTH and not check_collision_with_maze(player["x"] + player["speed"], player["y"]):
            player["x"] += player["speed"]
        if keys[pygame.K_UP] and player["y"] - player["speed"] >= 0 and not check_collision_with_maze(player["x"], player["y"] - player["speed"]):
            player["y"] -= player["speed"]
        if keys[pygame.K_DOWN] and player["y"] + player["speed"] + player["size"] <= HEIGHT and not check_collision_with_maze(player["x"], player["y"] + player["speed"]):
            player["y"] += player["speed"]


        # 📌 Usar ítems (Q, W, E)
        if keys[pygame.K_q]:
            use_inventory_item("stored_health")
        if keys[pygame.K_w]:
            use_inventory_item("stored_freeze")
        if keys[pygame.K_e]:
            use_inventory_item("stored_slow")

        # 📌 Movimiento de los rayos
        for ray in rays[:]:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed

        # Eliminar rayos fuera de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]

        # 📌 Regeneración de energía y salud
        regenerate_stats()

        # 📌 Misión: sobrevivir
        if player["health"] == player["max_health"]:
            update_mission_progress("survive_time")

        # 📌 Movimiento de enemigos con colisiones y borde de pantalla
        for enemy in enemies:
            dx = player["x"] - enemy["x"]
            dy = player["y"] - enemy["y"]
            distance = max(1, (dx ** 2 + dy ** 2) ** 0.5)

            if enemy["type"] == "hunter":
                new_x = enemy["x"] + (dx / distance) * enemy["speed"]
                new_y = enemy["y"] + (dy / distance) * enemy["speed"]

                if 0 <= new_x <= WIDTH - enemy["size"] and not check_collision_with_maze(new_x, enemy["y"]):
                    enemy["x"] = new_x
                if 0 <= new_y <= HEIGHT - enemy["size"] and not check_collision_with_maze(enemy["x"], new_y):
                    enemy["y"] = new_y

            elif enemy["type"] == "patroller":
                if enemy["direction"] == "LEFT" and enemy["x"] - enemy["speed"] >= 0:
                    enemy["x"] -= enemy["speed"]
                elif enemy["direction"] == "RIGHT" and enemy["x"] + enemy["speed"] + enemy["size"] <= WIDTH:
                    enemy["x"] += enemy["speed"]
                elif enemy["direction"] == "UP" and enemy["y"] - enemy["speed"] >= 0:
                    enemy["y"] -= enemy["speed"]
                elif enemy["direction"] == "DOWN" and enemy["y"] + enemy["speed"] + enemy["size"] <= HEIGHT:
                    enemy["y"] += enemy["speed"]

                if time.time() > enemy["change_direction_timer"] or check_collision_with_maze(enemy["x"], enemy["y"]):
                    enemy["direction"] = random.choice(["LEFT", "RIGHT", "UP", "DOWN"])
                    enemy["change_direction_timer"] = time.time() + random.uniform(1, 3)

            elif enemy["type"] == "erratic":
                if time.time() > enemy["change_direction_timer"]:
                    enemy["direction"] = random.choice(["LEFT", "RIGHT", "UP", "DOWN"])
                    enemy["change_direction_timer"] = time.time() + random.uniform(0.5, 2)

                if enemy["direction"] == "LEFT" and enemy["x"] - enemy["speed"] >= 0:
                    enemy["x"] -= enemy["speed"]
                elif enemy["direction"] == "RIGHT" and enemy["x"] + enemy["speed"] + enemy["size"] <= WIDTH:
                    enemy["x"] += enemy["speed"]
                elif enemy["direction"] == "UP" and enemy["y"] - enemy["speed"] >= 0:
                    enemy["y"] -= enemy["speed"]
                elif enemy["direction"] == "DOWN" and enemy["y"] + enemy["speed"] + enemy["size"] <= HEIGHT:
                    enemy["y"] += enemy["speed"]


        # 📌 Colisiones
        handle_collisions()

        # 📌 Subir de nivel si corresponde
        if player["exp"] >= player["exp_to_next_level"]:
            level_up()

        # 📌 Avanzar de ronda si no quedan enemigos
        if not enemies:
            advance_round()

        # 📌 Renderizar
        render_game()

        # 📌 Generar misión si no hay una activa
        if current_mission is None:
            generate_mission()

if __name__ == "__main__":
    main_menu()  # Mostrar el menú antes de iniciar el juego
    main()  # Iniciar el juego después de la selección









