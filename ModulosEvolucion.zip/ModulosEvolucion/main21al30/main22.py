import pygame
import random
import time  # Para manejar el cronómetro

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Fuente para mostrar texto
font = pygame.font.Font(None, 36)

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro


# Configuración del personaje con atributos avanzados
player = {
    "x": WIDTH // 2 - 25,
    "y": HEIGHT // 2 - 25,
    "size": 50,
    "color": (0, 255, 0),  # Verde por defecto
    "health": 100,
    "energy": 100,
    "strength": 10,  
    "resistance": 5,  
    "speed": 0.5,
    "exp": 0,
    "level": 1,
    "exp_to_next_level": 100
}


# Sistema de niveles
player_level = 1
player_exp = 0
exp_to_next_level = 100  

# Dirección inicial del disparo
last_direction = "UP"  

# Configuración de proyectiles y enemigos
projectile_types = {
    1: ((255, 0, 0), "Rojo"),
    2: ((0, 255, 0), "Verde"),
    3: ((0, 0, 255), "Azul"),
    4: ((255, 255, 0), "Amarillo"),
    5: ((255, 0, 255), "Magenta"),
    6: ((0, 255, 255), "Cian"),
    7: ((255, 165, 0), "Naranja"),
    8: ((128, 0, 128), "Púrpura"),
    9: ((255, 255, 255), "Blanco")
}
current_projectile_color = projectile_types[1][0]  

# Configuración del rayo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 5

# Configuración de rondas
current_round = 1
wave = 1  
enemy_speed = 0.2  
chase_range = 150  

# Contador de puntos y lista de enemigos
score = 0
enemies = []


# Lista de ítems y su configuración
items = []
ITEM_TYPES = {
    "health": ((0, 255, 0), "Salud"),  
    "freeze": ((0, 0, 255), "Congelación"),  
    "slow": ((255, 255, 0), "Reducción de Velocidad")  
}
freeze_timer = 0
slow_active = False

# Laberinto
maze_walls = []  

# Cronómetro
start_time = 0


def generate_enemies():
    """Genera enemigos con el color correspondiente a la ronda actual"""
    global enemies
    enemies = []
    
    round_color = projectile_types[current_round][0]  # Color de la ronda actual
    
    for _ in range(5):
        enemy_x = random.randint(5, WIDTH - player["size"] - 5)
        enemy_y = random.randint(5, HEIGHT - player["size"] - 5)
        
        enemy = {
            "x": enemy_x,
            "y": enemy_y,
            "size": player["size"],
            "color": round_color,  # 🔹 Ahora cada oleada es de un solo color
            "health": 100,
            "energy": 100,
            "strength": 8,
            "resistance": 3,
            "speed": 0.3
        }
        enemies.append(enemy)


def generate_items():
    """Genera ítems en posiciones aleatorias"""
    global items
    items = []
    for _ in range(3):  
        item_type = random.choice(list(ITEM_TYPES.keys()))
        item_x = random.randint(50, WIDTH - 50)
        item_y = random.randint(50, HEIGHT - 50)
        items.append([item_x, item_y, item_type])  

def generate_maze():
    """Genera un laberinto con paredes aleatorias"""
    global maze_walls
    maze_walls = []
    wall_size = 50  
    num_walls = 10  

    for _ in range(num_walls):
        wall_x = random.randint(1, (WIDTH // wall_size) - 2) * wall_size
        wall_y = random.randint(1, (HEIGHT // wall_size) - 2) * wall_size
        maze_walls.append((wall_x, wall_y, wall_size, wall_size))



def apply_item_effect(item_type):
    """Aplica efectos al jugador cuando recoge un ítem"""
    global freeze_timer, slow_active
    if item_type == "health":
        player["health"] = min(100, player["health"] + 30)
    elif item_type == "freeze":
        freeze_timer = time.time() + 5  
    elif item_type == "slow":
        slow_active = True  

def level_up():
    """Sube de nivel al jugador y mejora atributos"""
    player["level"] += 1  
    player["exp"] = 0  
    player["exp_to_next_level"] += 50  
    player["health"] = min(100, player["health"] + 20)  
    player["speed"] += 0.1  
    print(f"¡Nivel {player['level']}! Salud aumentada y velocidad mejorada.")



def apply_damage(attacker, defender):
    """Calcula el daño basado en la fuerza del atacante y la resistencia del defensor"""
    
    # Cálculo del daño base: fuerza del atacante menos resistencia del defensor
    damage = max(1, attacker["strength"] - defender["resistance"])  # Nunca menos de 1 de daño

    # Reducir la salud del defensor
    defender["health"] -= damage

    # Evitar que la salud sea negativa
    if defender["health"] < 0:
        defender["health"] = 0  
  


def check_collision_with_maze(x, y):
    """Verifica si el punto (x, y) colisiona con alguna pared del laberinto"""
    player_rect = pygame.Rect(x, y, player["size"], player["size"])  # Tamaño correcto del jugador
    
    for wall in maze_walls:
        wall_rect = pygame.Rect(wall[0], wall[1], wall[2], wall[3])  # Crear correctamente los rectángulos del laberinto
        if player_rect.colliderect(wall_rect):
            return True  # Hay colisión

    return False  # No hay colisión



def main_menu():
    """Muestra el menú de inicio"""
    menu_running = True
    while menu_running:
        screen.fill((0, 0, 0))
        title_text = font.render("Mi Juego en Pygame", True, (255, 255, 255))
        start_text = font.render("1 - Iniciar Juego", True, (255, 255, 255))
        exit_text = font.render("2 - Salir", True, (255, 255, 255))
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2))
        screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 50))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    menu_running = False  
                if event.key == pygame.K_2:
                    pygame.quit()
                    exit()



def game_over():
    """Muestra la pantalla de fin del juego con puntaje y tiempo"""
    screen.fill((0, 0, 0))
    game_over_text = font.render("¡Juego Finalizado!", True, (255, 255, 255))
    score_text = font.render(f"Puntos obtenidos: {score}", True, (255, 255, 255))
    time_text = font.render(f"Tiempo de juego: {int(time.time() - start_time)}s", True, (255, 255, 255))
    exit_text = font.render("Presiona ESC para salir", True, (255, 255, 255))
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 3))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
    screen.blit(time_text, (WIDTH // 2 - time_text.get_width() // 2, HEIGHT // 2 + 50))
    screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 100))
    pygame.display.flip()

    # Esperar hasta que el usuario presione ESC para salir
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit()
                exit()

                        
                
start_time = time.time()  # Guardar el tiempo de inicio del juego

# Bucle principal
def main():
    """Bucle principal del juego"""
    global current_round, wave, freeze_timer, slow_active, start_time, score, last_direction
    global current_projectile_color  # Agregar esta línea para que sea accesible dentro de la función
    start_time = time.time()  # Iniciar cronómetro
    generate_maze()  # Generar el laberinto al inicio
    generate_enemies()
    generate_items()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    last_direction = "LEFT"
                if event.key == pygame.K_RIGHT:
                    last_direction = "RIGHT"
                if event.key == pygame.K_UP:
                    last_direction = "UP"
                if event.key == pygame.K_DOWN:
                    last_direction = "DOWN"
                # Cambiar el color del proyectil con los números del 1 al 9
                if pygame.K_1 <= event.key <= pygame.K_9:
                    num = event.key - pygame.K_0
                    if num in projectile_types:
                        current_projectile_color = projectile_types[num][0]  # Ahora está bien definida

                # Cambiar el color del personaje con el número 0
                if event.key == pygame.K_0:
                    player["color"] = random.choice(list(projectile_types.values()))[0]
               
               
                # Disparar un rayo si hay suficiente energía
                if event.key == pygame.K_SPACE and player["energy"] >= 10:
                    ray_x = player["x"] + player["size"] // 2 - ray_width // 2
                    ray_y = player["y"] + player["size"] // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction, current_projectile_color])
                    player["energy"] -= 10  # Reducir energía por disparo               
            

        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()

        # Movimiento del jugador con restricción del laberinto
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player["x"] > 5 and not check_collision_with_maze(player["x"] - player["speed"], player["y"]):
            player["x"] -= player["speed"]
        if keys[pygame.K_RIGHT] and player["x"] < WIDTH - player["size"] - 5 and not check_collision_with_maze(player["x"] + player["speed"], player["y"]):
            player["x"] += player["speed"]
        if keys[pygame.K_UP] and player["y"] > 5 and not check_collision_with_maze(player["x"], player["y"] - player["speed"]):
            player["y"] -= player["speed"]
        if keys[pygame.K_DOWN] and player["y"] < HEIGHT - player["size"] - 5 and not check_collision_with_maze(player["x"], player["y"] + player["speed"]):
            player["y"] += player["speed"]

        # Movimiento de los rayos
        for ray in rays[:]:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed

        # Eliminar rayos fuera de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]

        # Regeneración de energía del jugador
        if player["energy"] < 100:
            player["energy"] += 0.1

        # Aplicar efecto de congelación si está activo
        if freeze_timer > time.time():
            enemy_movement_speed = 0  # Enemigos congelados
        else:
            enemy_movement_speed = enemy_speed / 2 if slow_active else enemy_speed

        # Movimiento de enemigos con restricción del laberinto
        for enemy in enemies:
            dx = player["x"] - enemy["x"]
            dy = player["y"] - enemy["y"]
            distance = max(1, (dx ** 2 + dy ** 2) ** 0.5)

            if distance < chase_range:
                enemy["x"] += (dx / distance) * enemy_movement_speed
                enemy["y"] += (dy / distance) * enemy_movement_speed
            else:
                enemy["x"] += random.choice([-1, 1]) * enemy_movement_speed
                enemy["y"] += random.choice([-1, 1]) * enemy_movement_speed 

        # Evitar que los enemigos salgan de los límites y colisionen con el laberinto
        for enemy in enemies:
            original_x, original_y = enemy["x"], enemy["y"]

            # Restringir dentro de los límites de la pantalla
            if enemy["x"] < 5:
                enemy["x"] = 5
            if enemy["x"] > WIDTH - enemy["size"] - 5:
                enemy["x"] = WIDTH - enemy["size"] - 5
            if enemy["y"] < 5:
                enemy["y"] = 5
            if enemy["y"] > HEIGHT - enemy["size"] - 5:
                enemy["y"] = HEIGHT - enemy["size"] - 5

            # Verificar colisión con el laberinto
            if check_collision_with_maze(enemy["x"], enemy["y"]):
                enemy["x"], enemy["y"] = original_x, original_y
                enemy["speed"] *= -1


        # Detección de colisiones con ítems
        for item in items[:]:
            if pygame.Rect(item[0], item[1], 20, 20).colliderect(pygame.Rect(player["x"], player["y"], player["size"], player["size"])):
                apply_item_effect(item[2])
                items.remove(item)  

        # Detección de colisiones entre rayos y enemigos
        for ray in rays[:]:
            for enemy in enemies[:]:
                if pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"]).colliderect(
                        pygame.Rect(ray[0], ray[1], ray_width, ray_height)):

                    if enemy["color"] == ray[3]:  # Solo si el color coincide
                        apply_damage(player, enemy)

                        if enemy["health"] <= 0:  # Si el enemigo muere
                            enemies.remove(enemy)
                            player["health"] = min(100, player["health"] + 5)  
                            player["energy"] = min(100, player["energy"] + 10)
                            
                            # 🔹 Ahora suma puntos correctamente
                            score += 100  # Puedes cambiar el valor si lo deseas
                            
                            # 🔹 Ahora suma experiencia correctamente
                            player["exp"] += 50  # Ajusta el valor según el sistema de niveles

                        rays.remove(ray)
                        break  # Salir del bucle para evitar errores de índice
                    
        # Detección de colisión entre el jugador y los enemigos
        for enemy in enemies:
            player_rect = pygame.Rect(player["x"], player["y"], player["size"], player["size"])
            enemy_rect = pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"])

            if player_rect.colliderect(enemy_rect):
                apply_damage(enemy, player)  # Aplicar daño del enemigo al jugador
                    




        # Verificar si el jugador sube de nivel
        if player["exp"] >= player["exp_to_next_level"]:
            level_up()

        # Avanzar de ronda cuando no quedan enemigos
        if not enemies:
            if wave == 1:
                wave = 2
                generate_enemies()
                generate_items()
            elif current_round < 9:
                current_round += 1
                wave = 1
                generate_maze()
                generate_enemies()
                generate_items()
            else:
                game_over()
        # Renderizado
        render_game()



def render_game():
    """Renderiza todos los elementos en pantalla"""
    screen.fill(BG_COLOR)

    # Dibujar laberinto
    for wall in maze_walls:
        pygame.draw.rect(screen, (200, 200, 200), wall)

    # Dibujar ítems
    for item in items:
        pygame.draw.rect(screen, ITEM_TYPES[item[2]][0], (item[0], item[1], 20, 20))

    # Dibujar personaje
    pygame.draw.rect(screen, player["color"], (player["x"], player["y"], player["size"], player["size"]))

    # Dibujar barra de salud del jugador sobre su cabeza
    pygame.draw.rect(screen, (255, 0, 0), (player["x"], player["y"] - 10, player["size"], 5))  # Fondo rojo
    pygame.draw.rect(screen, (0, 255, 0), (player["x"], player["y"] - 10, player["size"] * (player["health"] / 100), 5))  # Barra verde

    # Dibujar enemigos
    for enemy in enemies:
        pygame.draw.rect(screen, enemy["color"], (enemy["x"], enemy["y"], enemy["size"], enemy["size"]))
        
        # Dibujar barra de salud de los enemigos sobre sus cabezas
        pygame.draw.rect(screen, (255, 0, 0), (enemy["x"], enemy["y"] - 10, enemy["size"], 5))  # Fondo rojo
        pygame.draw.rect(screen, (0, 255, 0), (enemy["x"], enemy["y"] - 10, enemy["size"] * (enemy["health"] / 100), 5))  # Barra verde

    # Dibujar rayos
    for ray in rays:
        pygame.draw.rect(screen, ray[3], (ray[0], ray[1], ray_width, ray_height))

    # Mostrar información en pantalla
    level_text = font.render(f"Nivel: {player['level']}", True, (255, 255, 255))
    exp_text = font.render(f"EXP: {player['exp']}/{player['exp_to_next_level']}", True, (255, 255, 255))
    score_text = font.render(f"Puntos: {score}", True, (255, 255, 255))
    round_text = font.render(f"Ronda {current_round} - Oleada {wave}", True, (255, 255, 255))

    screen.blit(level_text, (20, 80))
    screen.blit(exp_text, (20, 110))
    screen.blit(score_text, (20, 20))
    screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 20))

    # Mostrar el tiempo transcurrido
    elapsed_time = int(time.time() - start_time)
    timer_text = font.render(f"Tiempo: {elapsed_time}s", True, (255, 255, 255))
    screen.blit(timer_text, (WIDTH - 150, 20))

    pygame.display.flip()
 

if __name__ == "__main__":
    main_menu()  # Mostrar el menú antes de iniciar el juego
    main()  # Iniciar el juego después de la selección























