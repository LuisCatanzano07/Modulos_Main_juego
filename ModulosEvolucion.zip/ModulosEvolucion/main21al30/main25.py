import pygame
import random
import time  # Para manejar el cronómetro

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Fuente para mostrar texto
font = pygame.font.Font(None, 36)

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje con atributos mejorables
player = {
    "x": WIDTH // 2 - 25,
    "y": HEIGHT // 2 - 25,
    "size": 50,
    "color": (0, 255, 0),  # Verde por defecto
    "health": 100,
    "max_health": 100,
    "energy": 100,
    "max_energy": 100,
    "strength": 10,  
    "resistance": 5,  
    "speed": 0.5,
    "exp": 0,  # Puntos de experiencia
    "exp_to_next_level": 100,  # Exp necesaria para subir de nivel
    "level": 1  # Nivel actual
}

# Configuración base de los enemigos
enemy_base_stats = {
    "size": 50,
    "health": 100,
    "max_health": 100,
    "energy": 100,
    "max_energy": 100,  # 🔹 Agregar este campo para evitar el KeyError
    "strength": 8,
    "resistance": 3,
    "speed": 0.3
}


# Dirección inicial del disparo
last_direction = "UP"  

# Configuración de proyectiles y enemigos
projectile_types = {
    1: ((255, 0, 0), "Rojo"),
    2: ((0, 255, 0), "Verde"),
    3: ((0, 0, 255), "Azul"),
    4: ((255, 255, 0), "Amarillo"),
    5: ((255, 0, 255), "Magenta"),
    6: ((0, 255, 255), "Cian"),
    7: ((255, 165, 0), "Naranja"),
    8: ((128, 0, 128), "Púrpura"),
    9: ((255, 255, 255), "Blanco")
}
current_projectile_color = projectile_types[1][0]  

# Configuración del rayo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 5

# Configuración de rondas
current_round = 1
wave = 1  
enemy_speed = 0.2  
chase_range = 150  

# Contador de puntos y lista de enemigos
score = 0
enemies = []

# Lista de ítems y su configuración
items = []
ITEM_TYPES = {
    "health": ((0, 255, 0), "Salud"),  
    "freeze": ((0, 0, 255), "Congelación"),  
    "slow": ((255, 255, 0), "Reducción de Velocidad")  
}
freeze_timer = 0
slow_active = False

# Laberinto
maze_walls = []

current_mission = None  # Misión activa del jugador
missions_completed = 0  # Contador de misiones completadas
  

# Cronómetro
start_time = 0

def generate_enemies():
    """Genera enemigos con diferentes comportamientos y estrategias."""
    global enemies
    enemies = []

    round_color = projectile_types[current_round][0]  # Color de la ronda actual
    
    for _ in range(5 + current_round * 2):  
        enemy_x = random.randint(5, WIDTH - player["size"] - 5)
        enemy_y = random.randint(5, HEIGHT - player["size"] - 5)

        enemy_type = random.choice(["hunter", "patroller", "erratic"])

        enemy = {
            "x": enemy_x,
            "y": enemy_y,
            "size": player["size"],
            "color": round_color,
            "health": enemy_base_stats["max_health"] + (current_round * 10),
            "max_health": enemy_base_stats["max_health"] + (current_round * 10),
            "energy": 100,
            "max_energy": enemy_base_stats["max_energy"],  # Asegurar que se copie correctamente
            "strength": enemy_base_stats["strength"] + (current_round * 2),
            "resistance": enemy_base_stats["resistance"] + (current_round * 1),
            "speed": enemy_base_stats["speed"] + (current_round * 0.05),
            "type": enemy_type,  
            "direction": random.choice(["LEFT", "RIGHT", "UP", "DOWN"]),
            "change_direction_timer": time.time() + random.uniform(1, 3)
        }
        print(enemy)  # 🔹 Muestra los atributos de los enemigos generados en la consola
        enemies.append(enemy)



def generate_items():
    """Genera ítems en posiciones aleatorias."""
    global items
    items = []
    for _ in range(3):  
        item_type = random.choice(list(ITEM_TYPES.keys()))
        item_x = random.randint(50, WIDTH - 50)
        item_y = random.randint(50, HEIGHT - 50)
        items.append([item_x, item_y, item_type])  
def generate_maze():
    """Genera un laberinto con paredes aleatorias"""
    global maze_walls  # Asegurar que estamos modificando la variable global
    maze_walls = []
    wall_size = 50  
    num_walls = 10  

    for _ in range(num_walls):
        wall_x = random.randint(1, (WIDTH // wall_size) - 2) * wall_size
        wall_y = random.randint(1, (HEIGHT // wall_size) - 2) * wall_size
        maze_walls.append((wall_x, wall_y, wall_size, wall_size))

def advance_round():
    """Avanza a la siguiente ronda y ajusta la dificultad."""
    global current_round, wave

    if wave == 1:
        wave = 2
        generate_enemies()
        generate_items()
    elif current_round < 9:
        current_round += 1
        wave = 1

        # 📌 Asegurar que las mejoras de los enemigos se mantengan en cada ronda
        enemy_base_stats["max_health"] += 10
        enemy_base_stats["strength"] += 2
        enemy_base_stats["resistance"] += 1
        enemy_base_stats["speed"] += 0.05  # Aumenta un poco la velocidad

        generate_maze()
        generate_enemies()
        generate_items()
    else:
        game_over()

def restart_game():
    """Reinicia el juego restaurando todas las variables y comenzando desde el principio."""
    global player, current_round, wave, score, enemies, items, rays, start_time

    # 📌 Restaurar atributos del jugador
    player.update({
        "x": WIDTH // 2 - 25,
        "y": HEIGHT // 2 - 25,
        "health": 100,
        "max_health": 100,
        "energy": 100,
        "max_energy": 100,
        "strength": 10,
        "resistance": 5,
        "speed": 0.5,
        "exp": 0,
        "exp_to_next_level": 100,
        "level": 1
    })

    # 📌 Restaurar progreso del juego
    current_round = 1
    wave = 1
    score = 0
    enemies = []
    items = []
    rays = []
    start_time = time.time()

    # 📌 Volver a generar todo
    generate_maze()
    generate_enemies()
    generate_items()

    # 📌 Reiniciar el bucle del juego
    main()
def apply_item_effect(item_type):
    """Aplica efectos al jugador cuando recoge un ítem"""
    global freeze_timer, slow_active
    if item_type == "health":
        player["health"] = min(player["max_health"], player["health"] + 30)  # 🔹 Usa max_health en la restauración
    elif item_type == "freeze":
        freeze_timer = time.time() + 5  # 🔹 Enemigos quedan congelados por 5 segundos
    elif item_type == "slow":
        slow_active = True  # 🔹 Activa la reducción de velocidad de enemigos por 10 segundos
def apply_damage(attacker, defender):
    """Calcula el daño basado en la fuerza del atacante y la resistencia del defensor."""
    damage = max(1, attacker["strength"] - defender["resistance"])
    defender["health"] -= damage

    if defender["health"] < 0:
        defender["health"] = 0  

    print(f"{attacker['color']} atacó a {defender['color']} e hizo {damage} de daño.")

    if defender["health"] == 0:
        print(f"{defender['color']} ha sido derrotado.")
def level_up():
    """Sube de nivel al jugador y mejora atributos."""
    player["level"] += 1  
    player["exp"] = 0  
    player["exp_to_next_level"] += 50  

    player["max_health"] += 10
    player["max_energy"] += 10
    player["strength"] += 2
    player["resistance"] += 1
    player["speed"] += 0.05

    player["health"] = player["max_health"]
    player["energy"] = player["max_energy"]

    print(f"¡Subiste al nivel {player['level']}! Salud, energía, fuerza y resistencia mejoradas.")
def check_collision_with_maze(x, y):
    """Verifica si el punto (x, y) colisiona con alguna pared del laberinto"""
    player_rect = pygame.Rect(x, y, player["size"], player["size"])  # 🔹 Tamaño correcto del jugador
    
    for wall in maze_walls:
        wall_rect = pygame.Rect(wall[0], wall[1], wall[2], wall[3])  # 🔹 Crea correctamente los rectángulos del laberinto
        if player_rect.colliderect(wall_rect):
            return True  # 🔹 Hay colisión

    return False  # 🔹 No hay colisión
def handle_collisions():
    """Gestiona todas las colisiones en el juego."""
    global score

    # 📌 Colisión entre jugador y enemigos
    for enemy in enemies:
        player_rect = pygame.Rect(player["x"], player["y"], player["size"], player["size"])
        enemy_rect = pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"])

        if player_rect.colliderect(enemy_rect):
            apply_damage(enemy, player)  # El enemigo ataca al jugador
            apply_damage(player, enemy)  # El jugador también contraataca

    # 📌 Colisión entre rayos y enemigos
    for ray in rays[:]:
        for enemy in enemies[:]:
            if pygame.Rect(enemy["x"], enemy["y"], enemy["size"], enemy["size"]).colliderect(
                    pygame.Rect(ray[0], ray[1], ray_width, ray_height)):

                if enemy["color"] == ray[3]:  # Solo si el color coincide
                    apply_damage(player, enemy)

                    if enemy["health"] <= 0:  
                        enemies.remove(enemy)
                        update_mission_progress("kill_enemies")  # Actualizar progreso de la misión

                        player["health"] = min(player["max_health"], player["health"] + 5)
                        player["energy"] = min(player["max_energy"], player["energy"] + 10)

                        # 🔹 Ahora suma puntos correctamente
                        score += 100  

                        # 🔹 Asignar experiencia basada en el nivel del enemigo
                        gained_exp = 50 + (enemy["strength"] * 2) + (enemy["resistance"] * 2)
                        player["exp"] += gained_exp
                        print(f"+{gained_exp} EXP ganada!")

                        # 🔹 Subir de nivel si se alcanza la experiencia necesaria
                        if player["exp"] >= player["exp_to_next_level"]:
                            level_up()

                    rays.remove(ray)
                    break  # Salir del bucle para evitar errores de índice

    # 📌 Colisión del jugador con ítems
    for item in items[:]:
        if pygame.Rect(item[0], item[1], 20, 20).colliderect(pygame.Rect(player["x"], player["y"], player["size"], player["size"])):
            apply_item_effect(item[2])
            items.remove(item)
            update_mission_progress("collect_items")  # Actualizar progreso de la misión

def regenerate_stats():
    """Regenera la salud y energía del jugador y enemigos."""
    # Regeneración de energía del jugador
    if player["energy"] < player["max_energy"]:
        player["energy"] += 0.1 + (player["level"] * 0.05)  # Aumenta con el nivel

    # Regeneración de salud del jugador si tiene alta resistencia
    if player["health"] < player["max_health"] and player["resistance"] > 5:
        player["health"] += 0.05 * player["resistance"]  # Cuanto más resistente, más rápido se regenera
        player["health"] = min(player["max_health"], player["health"])  # No sobrepasa el máximo

    # Regeneración de energía de los enemigos si tienen resistencia alta
    for enemy in enemies:
        if enemy["energy"] < enemy["max_energy"]:
            enemy["energy"] += 0.05 + (enemy["resistance"] * 0.02)  # Aumenta con resistencia
        if enemy["health"] < enemy["max_health"] and enemy["resistance"] > 5:
            enemy["health"] += 0.02 * enemy["resistance"]  # Enemigos más resistentes regeneran más salud
            enemy["health"] = min(enemy["max_health"], enemy["health"])  # No sobrepasa el máximo

def generate_mission():
    """Genera una nueva misión aleatoria."""
    global current_mission

    mission_types = [
        {"type": "kill_enemies", "goal": random.randint(3, 7), "description": "Elimina {} enemigos."},
        {"type": "survive_time", "goal": random.randint(15, 40), "description": "Sobrevive {} segundos sin ser golpeado."},
        {"type": "collect_items", "goal": random.randint(2, 5), "description": "Recoge {} ítems del mapa."},
        {"type": "shoot_projectiles", "goal": random.randint(5, 15), "description": "Dispara {} rayos."}
    ]

    current_mission = random.choice(mission_types)
    current_mission["progress"] = 0  # Inicializar el progreso
    current_mission["description"] = current_mission["description"].format(current_mission["goal"])
def complete_mission():
    """Otorga recompensas al completar una misión y genera una nueva."""
    global player, missions_completed

    rewards = [
        {"type": "exp", "value": random.randint(50, 150), "description": "+{} EXP"},
        {"type": "health", "value": 10, "description": "+10 Salud Máxima"},
        {"type": "energy", "value": 10, "description": "+10 Energía Máxima"},
        {"type": "strength", "value": 1, "description": "+1 Fuerza"},
        {"type": "speed", "value": 0.1, "description": "+0.1 Velocidad"}
    ]

    reward = random.choice(rewards)  # Selecciona una recompensa aleatoria
    missions_completed += 1

    if reward["type"] == "exp":
        player["exp"] += reward["value"]
    elif reward["type"] == "health":
        player["max_health"] += reward["value"]
        player["health"] = min(player["max_health"], player["health"] + reward["value"])
    elif reward["type"] == "energy":
        player["max_energy"] += reward["value"]
        player["energy"] = min(player["max_energy"], player["energy"] + reward["value"])
    elif reward["type"] == "strength":
        player["strength"] += reward["value"]
    elif reward["type"] == "speed":
        player["speed"] += reward["value"]

    print(f"🎉 Misión Completada! Recompensa: {reward['description'].format(reward['value'])}")

    generate_mission()  # Generar una nueva misión

def update_mission_progress(event_type, amount=1):
    """Actualiza el progreso de la misión según el evento."""
    global current_mission

    if not current_mission:
        return

    if current_mission["type"] == event_type:
        current_mission["progress"] += amount

        if current_mission["progress"] >= current_mission["goal"]:
            complete_mission()

def draw_status_bar(x, y, width, current_value, max_value, bg_color, fg_color):
    """Dibuja una barra de estado (salud o energía)"""
    pygame.draw.rect(screen, bg_color, (x, y, width, 5))  # Fondo
    bar_width = (current_value / max_value) * width
    pygame.draw.rect(screen, fg_color, (x, y, bar_width, 5))  # Barra de estado
def display_player_info():
    """Muestra el nivel, experiencia y puntos en pantalla"""
    level_text = font.render(f"Nivel: {player['level']}", True, (255, 255, 255))
    exp_text = font.render(f"EXP: {player['exp']}/{player['exp_to_next_level']}", True, (255, 255, 255))
    score_text = font.render(f"Puntos: {score}", True, (255, 255, 255))
    round_text = font.render(f"Ronda {current_round} - Oleada {wave}", True, (255, 255, 255))

    screen.blit(level_text, (20, 80))
    screen.blit(exp_text, (20, 110))
    screen.blit(score_text, (20, 20))
    screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 20))
def display_mission():
    """Muestra la misión actual en la pantalla."""
    if current_mission:
        mission_text = font.render(f"Misión: {current_mission['description']} ({current_mission['progress']}/{current_mission['goal']})", True, (255, 255, 255))
        screen.blit(mission_text, (20, 140))

def render_game():
    """Renderiza todos los elementos en pantalla."""
    screen.fill(BG_COLOR)  # 📌 Limpiar la pantalla antes de renderizar

    # 📌 Dibujar el laberinto
    for wall in maze_walls:
        pygame.draw.rect(screen, (200, 200, 200), wall)  # Color gris para las paredes

    # 📌 Dibujar ítems en pantalla
    for item in items:
        pygame.draw.rect(screen, ITEM_TYPES[item[2]][0], (item[0], item[1], 20, 20))

    # 📌 Dibujar personaje (jugador)
    pygame.draw.rect(screen, player["color"], (player["x"], player["y"], player["size"], player["size"]))

    # 📌 Dibujar barra de salud del jugador
    draw_status_bar(player["x"], player["y"] - 10, player["size"], player["health"], player["max_health"], (255, 0, 0), (0, 255, 0))

    # 📌 Dibujar barra de energía del jugador
    draw_status_bar(player["x"], player["y"] - 5, player["size"], player["energy"], player["max_energy"], (50, 50, 255), (0, 100, 255))

    # 📌 Dibujar enemigos
    for enemy in enemies:
        pygame.draw.rect(screen, enemy["color"], (enemy["x"], enemy["y"], enemy["size"], enemy["size"]))
        draw_status_bar(enemy["x"], enemy["y"] - 10, enemy["size"], enemy["health"], enemy["max_health"], (255, 0, 0), (0, 255, 0))

    # 📌 Dibujar rayos
    for ray in rays:
        pygame.draw.rect(screen, ray[3], (ray[0], ray[1], ray_width, ray_height))

    # 📌 Mostrar información del jugador en pantalla
    display_player_info()

    pygame.display.flip()  # 📌 Actualizar la pantalla después de renderizar
def pause_menu():
    """Menú de pausa para mejorar atributos del jugador y enemigos usando experiencia."""
    paused = True
    
    while paused:
        screen.fill((50, 50, 50))  # Fondo gris oscuro

        # Texto del menú
        title_text = font.render("Menú de Pausa - Mejora de Atributos", True, (255, 255, 255))
        exp_text = font.render(f"EXP Disponible: {player['exp']}", True, (255, 255, 255))
        resume_text = font.render("Presiona R para continuar", True, (255, 255, 255))

        # Opciones de mejora
        options = [
            "1 - Aumentar Salud (+20) [Coste: 50 EXP]",
            "2 - Aumentar Energía (+20) [Coste: 50 EXP]",
            "3 - Aumentar Fuerza (+2) [Coste: 75 EXP]",
            "4 - Aumentar Resistencia (+2) [Coste: 75 EXP]",
            "5 - Aumentar Velocidad (+0.1) [Coste: 100 EXP]",
            "6 - Aumentar Vida de Enemigos (+20) [Coste: 100 EXP]",
            "7 - Aumentar Fuerza de Enemigos (+2) [Coste: 125 EXP]",
            "8 - Aumentar Velocidad de Enemigos (+0.1) [Coste: 150 EXP]"
        ]

        # Dibujar los textos en pantalla
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, 50))
        screen.blit(exp_text, (WIDTH // 2 - exp_text.get_width() // 2, 100))
        screen.blit(resume_text, (WIDTH // 2 - resume_text.get_width() // 2, 500))

        for i, option in enumerate(options):
            option_text = font.render(option, True, (255, 255, 255))
            screen.blit(option_text, (WIDTH // 4, 150 + i * 40))

        pygame.display.flip()

        # Manejo de eventos del menú de pausa
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    paused = False  # Salir del menú de pausa

                # Mejoras del jugador
                elif event.key == pygame.K_1 and player["exp"] >= 50:
                    player["max_health"] += 20
                    player["exp"] -= 50
                elif event.key == pygame.K_2 and player["exp"] >= 50:
                    player["max_energy"] += 20
                    player["exp"] -= 50
                elif event.key == pygame.K_3 and player["exp"] >= 75:
                    player["strength"] += 2
                    player["exp"] -= 75
                elif event.key == pygame.K_4 and player["exp"] >= 75:
                    player["resistance"] += 2
                    player["exp"] -= 75
                elif event.key == pygame.K_5 and player["exp"] >= 100:
                    player["speed"] += 0.1
                    player["exp"] -= 100

                # Mejoras de enemigos
                elif event.key == pygame.K_6 and player["exp"] >= 100:
                    enemy_base_stats["max_health"] += 20
                    player["exp"] -= 100
                elif event.key == pygame.K_7 and player["exp"] >= 125:
                    enemy_base_stats["strength"] += 2
                    player["exp"] -= 125
                elif event.key == pygame.K_8 and player["exp"] >= 150:
                    enemy_base_stats["speed"] += 0.1
                    player["exp"] -= 150
def main_menu():
    """Muestra el menú de inicio"""
    menu_running = True
    while menu_running:
        screen.fill((0, 0, 0))
        title_text = font.render("Mi Juego en Pygame", True, (255, 255, 255))
        start_text = font.render("1 - Iniciar Juego", True, (255, 255, 255))
        exit_text = font.render("2 - Salir", True, (255, 255, 255))
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2))
        screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 50))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    menu_running = False  
                if event.key == pygame.K_2:
                    pygame.quit()
                    exit()
def game_over():
    """Muestra la pantalla de fin del juego con puntaje y tiempo."""
    global running

    screen.fill((0, 0, 0))  # Fondo negro

    # 📌 Mensajes de finalización
    game_over_text = font.render("¡Juego Finalizado!", True, (255, 255, 255))
    score_text = font.render(f"Puntos obtenidos: {score}", True, (255, 255, 255))
    time_text = font.render(f"Tiempo de juego: {int(time.time() - start_time)}s", True, (255, 255, 255))
    restart_text = font.render("Presiona R para reiniciar o ESC para salir", True, (255, 255, 255))

    # 📌 Posicionar textos
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 3))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
    screen.blit(time_text, (WIDTH // 2 - time_text.get_width() // 2, HEIGHT // 2 + 50))
    screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 100))

    pygame.display.flip()

    # 📌 Esperar entrada del usuario para salir o reiniciar
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    waiting = False  # Romper el bucle para reiniciar el juego
                    restart_game()
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()
               
start_time = time.time()  # Guardar el tiempo de inicio del juego
# Bucle principal
def main():
    """Bucle principal del juego"""
    global current_round, wave, freeze_timer, slow_active, start_time, score, last_direction
    global current_projectile_color  

    start_time = time.time()  # Iniciar cronómetro
    generate_maze()  
    generate_enemies()
    generate_items()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # Menú de pausa con tecla "P"
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                pause_menu()

            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
                    last_direction = {
                        pygame.K_LEFT: "LEFT",
                        pygame.K_RIGHT: "RIGHT",
                        pygame.K_UP: "UP",
                        pygame.K_DOWN: "DOWN"
                    }[event.key]

                # Cambiar el color del proyectil con los números del 1 al 9
                if pygame.K_1 <= event.key <= pygame.K_9:
                    num = event.key - pygame.K_0
                    if num in projectile_types:
                        current_projectile_color = projectile_types[num][0]

                # Cambiar el color del personaje con el número 0
                if event.key == pygame.K_0:
                    player["color"] = random.choice(list(projectile_types.values()))[0]
               
                # Disparar un rayo si hay suficiente energía
                if event.key == pygame.K_SPACE and player["energy"] >= 10:
                    ray_x = player["x"] + player["size"] // 2 - ray_width // 2
                    ray_y = player["y"] + player["size"] // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction, current_projectile_color])
                    player["energy"] -= 10
                    update_mission_progress("shoot_projectiles")  # Actualizar progreso de la misión


        # Movimiento del jugador con restricción del laberinto
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player["x"] > 5 and not check_collision_with_maze(player["x"] - player["speed"], player["y"]):
            player["x"] -= player["speed"]
        if keys[pygame.K_RIGHT] and player["x"] < WIDTH - player["size"] - 5 and not check_collision_with_maze(player["x"] + player["speed"], player["y"]):
            player["x"] += player["speed"]
        if keys[pygame.K_UP] and player["y"] > 5 and not check_collision_with_maze(player["x"], player["y"] - player["speed"]):
            player["y"] -= player["speed"]
        if keys[pygame.K_DOWN] and player["y"] < HEIGHT - player["size"] - 5 and not check_collision_with_maze(player["x"], player["y"] + player["speed"]):
            player["y"] += player["speed"]

        # Movimiento de los rayos
        for ray in rays[:]:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed

        # Eliminar rayos fuera de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]

        # Regeneración de energía y salud
        regenerate_stats()

        if player["health"] == player["max_health"]:  
            update_mission_progress("survive_time")



        # Aplicar efecto de congelación si está activo
        enemy_movement_speed = 0 if freeze_timer > time.time() else enemy_speed / 2 if slow_active else enemy_speed

        # Movimiento de enemigos con restricción del laberinto
        for enemy in enemies:
            dx = player["x"] - enemy["x"]
            dy = player["y"] - enemy["y"]
            distance = max(1, (dx ** 2 + dy ** 2) ** 0.5)

            if enemy["type"] == "hunter":  
                enemy["x"] += (dx / distance) * enemy["speed"]
                enemy["y"] += (dy / distance) * enemy["speed"]

            elif enemy["type"] == "patroller":  
                if enemy["direction"] == "LEFT":
                    enemy["x"] -= enemy["speed"]
                elif enemy["direction"] == "RIGHT":
                    enemy["x"] += enemy["speed"]
                elif enemy["direction"] == "UP":
                    enemy["y"] -= enemy["speed"]
                elif enemy["direction"] == "DOWN":
                    enemy["y"] += enemy["speed"]

                if time.time() > enemy["change_direction_timer"] or check_collision_with_maze(enemy["x"], enemy["y"]):
                    enemy["direction"] = random.choice(["LEFT", "RIGHT", "UP", "DOWN"])
                    enemy["change_direction_timer"] = time.time() + random.uniform(1, 3)

            elif enemy["type"] == "erratic":  
                if time.time() > enemy["change_direction_timer"]:
                    enemy["direction"] = random.choice(["LEFT", "RIGHT", "UP", "DOWN"])
                    enemy["change_direction_timer"] = time.time() + random.uniform(0.5, 2)

                if enemy["direction"] == "LEFT":
                    enemy["x"] -= enemy["speed"]
                elif enemy["direction"] == "RIGHT":
                    enemy["x"] += enemy["speed"]
                elif enemy["direction"] == "UP":
                    enemy["y"] -= enemy["speed"]
                elif enemy["direction"] == "DOWN":
                    enemy["y"] += enemy["speed"]

        # Evitar que los enemigos salgan de los límites y colisionen con el laberinto
        for enemy in enemies:
            original_x, original_y = enemy["x"], enemy["y"]

            if enemy["x"] < 5:
                enemy["x"] = 5
            if enemy["x"] > WIDTH - enemy["size"] - 5:
                enemy["x"] = WIDTH - enemy["size"] - 5
            if enemy["y"] < 5:
                enemy["y"] = 5
            if enemy["y"] > HEIGHT - enemy["size"] - 5:
                enemy["y"] = HEIGHT - enemy["size"] - 5

            if check_collision_with_maze(enemy["x"], enemy["y"]):
                enemy["x"], enemy["y"] = original_x, original_y
                enemy["speed"] *= -1

        # Manejar colisiones (jugador vs enemigos, rayos vs enemigos, ítems)
        handle_collisions()

        # Verificar si el jugador sube de nivel
        if player["exp"] >= player["exp_to_next_level"]:
            level_up()

        # Avanzar de ronda si no quedan enemigos
        if not enemies:
            advance_round()

        # Renderizar el juego
        render_game()
        generate_mission()

if __name__ == "__main__":
    main_menu()  # Mostrar el menú antes de iniciar el juego
    main()  # Iniciar el juego después de la selección























