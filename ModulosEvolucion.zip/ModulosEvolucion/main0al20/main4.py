import pygame

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje
player_color = (0, 255, 0)  # Verde
player_size = 50
player_x = WIDTH // 2 - player_size // 2
player_y = HEIGHT // 2 - player_size // 2
player_speed = 5

# Dirección inicial del disparo
last_direction = "UP"

# Configuración del rayo
ray_color = (255, 255, 0)  # Amarillo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 10

# Bucle principal
def main():
    global player_x, player_y, last_direction
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    last_direction = "LEFT"
                if event.key == pygame.K_RIGHT:
                    last_direction = "RIGHT"
                if event.key == pygame.K_UP:
                    last_direction = "UP"
                if event.key == pygame.K_DOWN:
                    last_direction = "DOWN"
                
                # Disparar un rayo en la última dirección
                if event.key == pygame.K_SPACE:
                    ray_x = player_x + player_size // 2 - ray_width // 2
                    ray_y = player_y + player_size // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction])
        
        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= player_speed
        if keys[pygame.K_RIGHT]:
            player_x += player_speed
        if keys[pygame.K_UP]:
            player_y -= player_speed
        if keys[pygame.K_DOWN]:
            player_y += player_speed

        # Mover los rayos según la dirección
        for ray in rays:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed
        
        # Eliminar rayos que salgan de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]

        # Rellenar la pantalla con el color de fondo
        screen.fill(BG_COLOR)
        
        # Dibujar el personaje
        pygame.draw.rect(screen, player_color, (player_x, player_y, player_size, player_size))
        
        # Dibujar los rayos
        for ray in rays:
            pygame.draw.rect(screen, ray_color, (ray[0], ray[1], ray_width, ray_height))
        
        # Actualizar la pantalla
        pygame.display.flip()
    
    pygame.quit()

if __name__ == "__main__":
    main()




