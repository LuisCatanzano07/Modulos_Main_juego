import pygame
import random
import time  # Importamos time para manejar el cronómetro

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Fuente para mostrar texto
font = pygame.font.Font(None, 36)

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje
player_size = 50
player_x = WIDTH // 2 - player_size // 2
player_y = HEIGHT // 2 - player_size // 2
player_speed = 0.5
player_color = (0, 255, 0)  # Verde por defecto
player_health = 100  # Barra de salud del personaje
health_bar_width = 200  # Ancho de la barra de salud

# Dirección inicial del disparo
last_direction = "UP"

# Configuración de los tipos de proyectiles y enemigos
projectile_types = {
    1: ((255, 0, 0), "Rojo"),
    2: ((0, 255, 0), "Verde"),
    3: ((0, 0, 255), "Azul"),
    4: ((255, 255, 0), "Amarillo"),
    5: ((255, 0, 255), "Magenta"),
    6: ((0, 255, 255), "Cian"),
    7: ((255, 165, 0), "Naranja"),
    8: ((128, 0, 128), "Púrpura"),
    9: ((255, 255, 255), "Blanco")
}
current_projectile_color = projectile_types[1][0]  # Rojo por defecto

# Configuración del rayo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 5

# Configuración de las rondas
current_round = 1
round_active = True
round_color = projectile_types[current_round][0]
num_enemies = 5
wave = 1  # 1 = estáticos, 2 = perseguidores
enemy_speed = 0.2  # Velocidad del enemigo
chase_range = 150  # Rango en el que los enemigos empiezan a perseguir al jugador

# Contador de puntos y lista de enemigos
score = 0
enemies = []

# Lista de ítems y su configuración
items = []
ITEM_TYPES = {
    "health": ((0, 255, 0), "Salud"),  # Verde - Restaura salud
    "freeze": ((0, 0, 255), "Congelación"),  # Azul - Congela enemigos
    "slow": ((255, 255, 0), "Reducción de Velocidad")  # Amarillo - Reduce velocidad
}
freeze_timer = 0
slow_active = False

# Cronómetro
start_time = 0

# Configuración del laberinto
maze_walls = []  # Lista para almacenar las paredes del laberinto

def generate_enemies():
    global enemies, round_color, wave
    enemies = []
    for _ in range(num_enemies):
        enemy_x = random.randint(5, WIDTH - player_size - 5)  # Dentro del borde
        enemy_y = random.randint(5, HEIGHT - player_size - 5)  # Dentro del borde
        enemies.append([enemy_x, enemy_y, round_color, "wandering", random.choice([-1, 1]), random.choice([-1, 1])])

def generate_items():
    global items
    items = []  # Reiniciar la lista de ítems en cada ronda
    for _ in range(3):  # Generar 3 ítems por ronda
        item_type = random.choice(list(ITEM_TYPES.keys()))  # Seleccionar un tipo aleatorio
        item_x = random.randint(50, WIDTH - 50)
        item_y = random.randint(50, HEIGHT - 50)
        items.append([item_x, item_y, item_type])  # Guardar en la lista

def generate_maze():
    global maze_walls
    maze_walls = []  # Reiniciar laberinto por ronda

    wall_size = 50  # Tamaño de las paredes del laberinto
    num_walls = 10  # Número de paredes por laberinto

    for _ in range(num_walls):
        wall_x = random.randint(1, (WIDTH // wall_size) - 2) * wall_size
        wall_y = random.randint(1, (HEIGHT // wall_size) - 2) * wall_size
        maze_walls.append((wall_x, wall_y, wall_size, wall_size))  # Guardar cada pared
        

def check_collision_with_maze(x, y):
    """ Verifica si el punto (x, y) colisiona con alguna pared del laberinto """
    player_rect = pygame.Rect(x, y, player_size, player_size)
    for wall in maze_walls:
        wall_rect = pygame.Rect(wall)
        if player_rect.colliderect(wall_rect):
            return True  # Hay colisión
    return False


def main_menu():
    menu_running = True
    while menu_running:
        screen.fill((0, 0, 0))  # Fondo negro

        # Texto del menú
        title_text = font.render("Mi Juego en Pygame", True, (255, 255, 255))
        start_text = font.render("1 - Iniciar Juego", True, (255, 255, 255))
        exit_text = font.render("2 - Salir", True, (255, 255, 255))

        # Posicionar los textos
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2))
        screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    menu_running = False  # Comenzar el juego
                if event.key == pygame.K_2:
                    pygame.quit()
                    exit()

def game_over():
    screen.fill((0, 0, 0))  # Fondo negro

    # Mensajes de finalización
    game_over_text = font.render("¡Juego Finalizado!", True, (255, 255, 255))
    score_text = font.render(f"Puntos obtenidos: {score}", True, (255, 255, 255))
    time_text = font.render(f"Tiempo de juego: {int(time.time() - start_time)}s", True, (255, 255, 255))
    exit_text = font.render("Presiona ESC para salir", True, (255, 255, 255))

    # Posicionar textos
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 3))
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
    screen.blit(time_text, (WIDTH // 2 - time_text.get_width() // 2, HEIGHT // 2 + 50))
    screen.blit(exit_text, (WIDTH // 2 - exit_text.get_width() // 2, HEIGHT // 2 + 100))

    pygame.display.flip()

    # Esperar hasta que el jugador presione ESC para salir
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit()
                exit()

def apply_item_effect(item_type):
    global player_health, enemy_speed, freeze_timer, slow_active

    if item_type == "health":
        player_health = min(100, player_health + 30)  # Restaurar salud hasta el máximo

    elif item_type == "freeze":
        freeze_timer = time.time() + 5  # Congelar enemigos por 5 segundos

    elif item_type == "slow":
        slow_active = True  # Reducir la velocidad de los enemigos
                
                
start_time = time.time()  # Guardar el tiempo de inicio del juego

# Bucle principal
def main():
    global player_x, player_y, last_direction, current_projectile_color, current_round
    global round_active, round_color, player_color, score, wave, player_health, freeze_timer, slow_active, start_time

    start_time = time.time()  # Guardar el tiempo de inicio del juego
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # Capturar la última dirección presionada
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    last_direction = "LEFT"
                if event.key == pygame.K_RIGHT:
                    last_direction = "RIGHT"
                if event.key == pygame.K_UP:
                    last_direction = "UP"
                if event.key == pygame.K_DOWN:
                    last_direction = "DOWN"

                # Cambiar el color del proyectil con los números del 1 al 9
                if pygame.K_1 <= event.key <= pygame.K_9:
                    num = event.key - pygame.K_0
                    if num in projectile_types:
                        current_projectile_color = projectile_types[num][0]

                # Cambiar el color del personaje con el número 0
                if event.key == pygame.K_0:
                    player_color = random.choice(list(projectile_types.values()))[0]

                # Disparar un rayo en la última dirección con el color actual
                if event.key == pygame.K_SPACE:
                    ray_x = player_x + player_size // 2 - ray_width // 2
                    ray_y = player_y + player_size // 2 - ray_width // 2
                    rays.append([ray_x, ray_y, last_direction, current_projectile_color])

        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()

        # Restringir el movimiento del personaje dentro de los límites y del laberinto
        if keys[pygame.K_LEFT] and player_x > 5 and not check_collision_with_maze(player_x - player_speed, player_y):
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < WIDTH - player_size - 5 and not check_collision_with_maze(player_x + player_speed, player_y):
            player_x += player_speed
        if keys[pygame.K_UP] and player_y > 5 and not check_collision_with_maze(player_x, player_y - player_speed):
            player_y -= player_speed
        if keys[pygame.K_DOWN] and player_y < HEIGHT - player_size - 5 and not check_collision_with_maze(player_x, player_y + player_speed):
            player_y += player_speed


        # Mover los rayos según la dirección
        for ray in rays[:]:
            if ray[2] == "UP":
                ray[1] -= ray_speed
            elif ray[2] == "DOWN":
                ray[1] += ray_speed
            elif ray[2] == "LEFT":
                ray[0] -= ray_speed
            elif ray[2] == "RIGHT":
                ray[0] += ray_speed

        # Eliminar rayos que salgan de la pantalla
        rays[:] = [ray for ray in rays if 0 <= ray[0] <= WIDTH and 0 <= ray[1] <= HEIGHT]


        # Aplicar efecto de congelación si está activo
        if freeze_timer > time.time():
            enemy_movement_speed = 0  # Enemigos congelados
        else:
            enemy_movement_speed = enemy_speed / 2 if slow_active else enemy_speed  # Restaurar o reducir velocidad

        # Mover los enemigos con restricciones del laberinto
        for enemy in enemies:
            dx = player_x - enemy[0]
            dy = player_y - enemy[1]
            distance = (dx ** 2 + dy ** 2) ** 0.5

            if distance < chase_range:
                enemy[3] = "chasing"
                new_x = enemy[0] + (dx / distance) * enemy_movement_speed
                new_y = enemy[1] + (dy / distance) * enemy_movement_speed

                if not check_collision_with_maze(new_x, new_y):  # Solo moverse si no hay colisión
                    enemy[0] = new_x
                    enemy[1] = new_y
            else:
                enemy[3] = "wandering"
                new_x = enemy[0] + enemy[4] * enemy_movement_speed
                new_y = enemy[1] + enemy[5] * enemy_movement_speed

                if not check_collision_with_maze(new_x, new_y):  # Evitar paredes
                    enemy[0] = new_x
                    enemy[1] = new_y
                else:
                    enemy[4] *= -1  # Cambiar dirección horizontal
                    enemy[5] *= -1  # Cambiar dirección vertical


        # Evitar que los enemigos salgan de los límites
        for enemy in enemies:
            if enemy[0] < 5:
                enemy[0] = 5
                enemy[4] *= -1  # Cambia dirección horizontal
            if enemy[0] > WIDTH - player_size - 5:
                enemy[0] = WIDTH - player_size - 5
                enemy[4] *= -1
            if enemy[1] < 5:
                enemy[1] = 5
                enemy[5] *= -1  # Cambia dirección vertical
            if enemy[1] > HEIGHT - player_size - 5:
                enemy[1] = HEIGHT - player_size - 5
                enemy[5] *= -1


            
        # Detectar colisión del personaje con los enemigos y reducir salud
        for enemy in enemies:
            if pygame.Rect(enemy[0], enemy[1], player_size, player_size).colliderect(
                    pygame.Rect(player_x, player_y, player_size, player_size)):
                player_health -= 10  # Reducir salud al contacto con el enemigo
                player_health = max(0, player_health)  # Evitar valores negativos           
        
        # Detectar colisión del jugador con los ítems
        for item in items[:]:
            if pygame.Rect(item[0], item[1], 20, 20).colliderect(
                    pygame.Rect(player_x, player_y, player_size, player_size)):
                apply_item_effect(item[2])  # Aplicar efecto del ítem
                items.remove(item)  # Eliminar ítem recogido

        # Detectar colisiones entre rayos y enemigos
        for ray in rays[:]:
            for enemy in enemies[:]:
                if pygame.Rect(enemy[0], enemy[1], player_size, player_size).colliderect(
                        pygame.Rect(ray[0], ray[1], ray_width, ray_height)):
                    if enemy[2] == ray[3]:  # Solo eliminar si los colores coinciden
                        if player_color == enemy[2]:
                            score += 100
                        else:
                            score += 50
                        enemies.remove(enemy)
                        rays.remove(ray)
                        player_health += 5  # Recuperar salud al eliminar enemigo
                        player_health = min(100, player_health)  # Límite de salud a 100
                        break


        # Avanzar de ronda cuando no queden enemigos
        if not enemies:
            if wave == 1:
                wave = 2
                generate_enemies()
                generate_items()
            elif current_round < 9:
                current_round += 1
                wave = 1
                round_color = projectile_types[current_round][0]
                generate_maze()  # Generar nuevo laberinto
                generate_enemies()
                generate_items()
            else:
                game_over()



        # Dibujar elementos en pantalla
        screen.fill(BG_COLOR)

        # Dibujar la barra de salud
        pygame.draw.rect(screen, (255, 0, 0), (20, 50, health_bar_width, 10))  # Barra roja
        pygame.draw.rect(screen, (0, 255, 0), (20, 50, (player_health / 100) * health_bar_width, 10))  # Barra verde

        # Dibujar los ítems en pantalla
        for item in items:
            pygame.draw.rect(screen, ITEM_TYPES[item[2]][0], (item[0], item[1], 20, 20))

        # Dibujar el personaje
        pygame.draw.rect(screen, player_color, (player_x, player_y, player_size, player_size))

        # Dibujar los rayos
        for ray in rays:
            pygame.draw.rect(screen, ray[3], (ray[0], ray[1], ray_width, ray_height))

        # Dibujar los enemigos
        for enemy in enemies:
            pygame.draw.rect(screen, round_color, (enemy[0], enemy[1], player_size, player_size))

        # Dibujar los límites de la pantalla
        pygame.draw.rect(screen, (255, 255, 255), (0, 0, WIDTH, HEIGHT), 5)  # Recuadro blanco

        # Mostrar el tiempo transcurrido
        elapsed_time = int(time.time() - start_time)
        timer_text = font.render(f"Tiempo: {elapsed_time}s", True, (255, 255, 255))
        screen.blit(timer_text, (WIDTH - 150, 20))

        # Mostrar texto de la ronda y puntaje
        round_text = font.render(f"Ronda {current_round} - Oleada {wave}", True, (255, 255, 255))
        score_text = font.render(f"Puntos: {score}", True, (255, 255, 255))
        screen.blit(round_text, (WIDTH // 2 - round_text.get_width() // 2, 20))
        screen.blit(score_text, (20, 20))
        
        # Dibujar el laberinto
        for wall in maze_walls:
            pygame.draw.rect(screen, (200, 200, 200), wall)  # Paredes en gris


        pygame.display.flip()


    pygame.quit()

if __name__ == "__main__":
    main_menu()  # Llamar al menú antes de iniciar el juego
    main()  # Iniciar el juego después de la selección




















