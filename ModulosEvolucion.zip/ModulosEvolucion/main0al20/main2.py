import pygame

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje
player_color = (0, 255, 0)  # Verde
player_size = 50
player_x = WIDTH // 2 - player_size // 2
player_y = HEIGHT // 2 - player_size // 2
player_speed = 1

# Bucle principal
def main():
    global player_x, player_y
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= player_speed
        if keys[pygame.K_RIGHT]:
            player_x += player_speed
        if keys[pygame.K_UP]:
            player_y -= player_speed
        if keys[pygame.K_DOWN]:
            player_y += player_speed

        # Rellenar la pantalla con el color de fondo
        screen.fill(BG_COLOR)
        
        # Dibujar el personaje
        pygame.draw.rect(screen, player_color, (player_x, player_y, player_size, player_size))
        
        # Actualizar la pantalla
        pygame.display.flip()
    
    pygame.quit()

if __name__ == "__main__":
    main()


