import pygame

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mi Juego en Pygame")

# Color de fondo
BG_COLOR = (30, 30, 30)  # Un gris oscuro

# Configuración del personaje
player_color = (0, 255, 0)  # Verde
player_size = 50
player_x = WIDTH // 2 - player_size // 2
player_y = HEIGHT // 2 - player_size // 2
player_speed = 1

# Configuración del rayo
ray_color = (255, 255, 0)  # Amarillo
ray_width = 5
ray_height = 20
rays = []
ray_speed = 5

# Bucle principal
def main():
    global player_x, player_y
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # Disparar un rayo con la barra espaciadora
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    ray_x = player_x + player_size // 2 - ray_width // 2
                    ray_y = player_y
                    rays.append([ray_x, ray_y])
        
        # Obtener las teclas presionadas
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= player_speed
        if keys[pygame.K_RIGHT]:
            player_x += player_speed
        if keys[pygame.K_UP]:
            player_y -= player_speed
        if keys[pygame.K_DOWN]:
            player_y += player_speed

        # Mover los rayos
        for ray in rays:
            ray[1] -= ray_speed
        
        # Eliminar rayos que salgan de la pantalla
        rays[:] = [ray for ray in rays if ray[1] > 0]

        # Rellenar la pantalla con el color de fondo
        screen.fill(BG_COLOR)
        
        # Dibujar el personaje
        pygame.draw.rect(screen, player_color, (player_x, player_y, player_size, player_size))
        
        # Dibujar los rayos
        for ray in rays:
            pygame.draw.rect(screen, ray_color, (ray[0], ray[1], ray_width, ray_height))
        
        # Actualizar la pantalla
        pygame.display.flip()
    
    pygame.quit()

if __name__ == "__main__":
    main()



